
All the datasets are released on Kaggle. Click [here](https://www.kaggle.com/c/jigsaw-multilingual-toxic-comment-classification/data) to access the datasets. 

Also we have a copy of those datasets and uploaded them to Google Drive, here is the [link](https://drive.google.com/drive/folders/13cz8Xytgb1-QrSws4Q6cJvSzRTSC_thK?usp=sharing).

