## Please write your reviews for your model [here](https://docs.google.com/document/d/13hSy6i-ZoHPSfpQytqIrQr-4s-QvpJoBbG245fabS5o/edit?usp=sharing)

## Plese fill in your tuning results [here](https://docs.google.com/spreadsheets/d/122Hq9oaRnv1EryEPNJ2yELZ_CBQuluWY-R2MJi3Cklk/edit?usp=sharing)


Deadlines:
- review ddl: wed 23:59 
- coding ddl: S: thur 12:00, J & R : Sat 12:00
- proposal writing: Sat: 23:59