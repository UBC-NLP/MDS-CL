## Introduction

[Jigsaw Multilingual Toxic Comment Classification](https://www.kaggle.com/c/jigsaw-multilingual-toxic-comment-classification/overview/description) is Kaggle competition launched by [Jigsaw](https://jigsaw.google.com/) and Google. This is a text classification task which aims to identify whether or not a comment is toxic. Toxicity here means rude, disrespectful or any inappropriate comments that will make people uncomfortable. In this project, our inputs are multilingual comments and we are expected to predict if it is toxic.

## Motivation and Contributions/Originality
Toxic comments have always been an issue online, because it only takes one to sour things and derail discussions. Given the prominence of social media nowadays, the growing impacts of toxic comments are becoming more concerning. For example, South Korean singer/actress Sulli's suicide was supposedly linked to depression caused by cyberbullying. Throughout her career, she had to constantly battle toxic, malicious comments directed towards her online. Unfortunately, Sulli's situation only came to light because of her status and it's only the tip of the iceberg. We hope to contribute by developing a system that is more robust than existing toxic-comment detecting models.

## Data

All the data is available on Kaggle. Click [here](https://www.kaggle.com/c/jigsaw-multilingual-toxic-comment-classification/data) to access the datasets. Also we have a copy of those datasets and uploaded them to Google Drive, here is the [link](https://drive.google.com/drive/folders/13cz8Xytgb1-QrSws4Q6cJvSzRTSC_thK?usp=sharing).

#### **jigsaw-toxic-comment-train.csv**. The dataset is made up of English comments from Wikipedia’s talk page edits. (**223,549** unique comments)

|id|comment_text|toxic|severe_toxic|obscene|threat|insult|identity_hate|
|--|------------|-----|------------|-------|------|------|-------------|
|1|0000997932d777bf|	Explanation Why the edits made under my username Hardcore Metallica Fan were reverted? They weren't vandalisms, just closure on some GAs after I voted at New York Dolls FAC. And please don't remove th...	|0	|0	|0	|0	|0	|0|

#### **jigsaw-unintended-bias-train.csv**. This is an expanded version of the Civil Comments dataset with a range of additional labels. (**1,876,468** unique comments)

|id|comment_text|toxic|severe_toxicity|obscene|identity_attack|insult|threat|....|
|--|------------|-----|------------|-------|------|------|--|---|
|1	|This is so cool. It's like, 'would you want your mother to read this??' Really great idea, well done!	|0.0|	0.0	|0.0|	0.0	|0.0|	0.0		|										

#### **sample_submission.csv** - a sample submission file in the correct format


|id |toxic|
|---|-----|
| 0 | 1.0 |

#### **test.csv** - comments from Wikipedia talk pages in different non-English languages. (**63,812** unique comments)


|id|content|lang|
|--|-------|----|
|0 |	Doctor Who adlı viki başlığına 12. doctor olarak bir viki yazarı kendi adını eklemiştir. Şahsen düzelttim. Onaylarsanız sevinirim. Occipital	|tr|


#### **validation.csv** - comments from Wikipedia talk pages in different non-English languages. (**8,000** unique comments)

|tr|es|it|
|--|--|--|
|38%|31%|31%|

|id|comment_text|lang|toxic|
|--|-------|----|---|
|1	|0	|Este usuario ni siquiera llega al rango de hereje . Por lo tanto debería ser quemado en la barbacoa para purificar su alma y nuestro aparato digestivo mediante su ingestión. Skipe linkin 22px ...	|es	|0|

#### **jigsaw-toxic-comment-train-processed-seqlen128.csv** - training data preprocessed for BERT

#### **jigsaw-unintended-bias-train-processed-seqlen128.csv** - training data preprocessed for BERT

#### **validation-processed-seqlen128.csv** - validation data preprocessed for BERT

#### **test-processed-seqlen128.csv** - test data preprocessed for BERT


## Methods and Engineering

This week, we proposed to try two pre-trained models on our classification task: MBERT and XLM-RoBERTa. We have engineered both models and succesfully run them in Google Colab as well as Kaggle GPU/TPU. Here are more details:


- MBERT Model:

    We loaded the pre-trained `bert-base-multilingual-cased` model from the `transformers` package. Also, we used the corresponding pre-trained tokenizer in this model as our tokenizer. We have tried to feed in different representations to the linear classification layer on top of the Bert model:

    - The representation of the `[CLS]` token from the last layer
    - The representation of the `[CLS]` token across all layers
    - The classes for our models can be found [here](https://github.ubc.ca/jchn1202/COLX_585_JC_RL_SG/blob/master/Milestone_2/BertStructures.ipynb)

    - `bert-base-multilingual-cased`
        - 12-layers
        - 768-hidden-state
        - 12-heads
        - 110 Million parameters

- XLM-RoBERTa Model:

    [documnet](https://huggingface.co/transformers/model_doc/xlmroberta.html) is here. In this week, we use `xlm-roberta-base` model. During preprocessing, we add `<s>` as cls_token, `</s>` as eos_token and `<pad>` as paddings.

    - `xlm-roberta-base`
        - 12-layers
        - 768-hidden-state
        - 3072 feed-forward hidden-state
        - 8-heads

    ~125M parameters trained on 2.5 TB of newly created clean CommonCrawl data in 100 languages. *The **Common Crawl** corpus contains petabytes of data collected over 8 years of web crawling. The corpus contains raw web page data, metadata extracts and text extracts.*

    - `xlm-roberta-large`
        - 24-layers
        - 1027-hidden-state
        - 4096 feed-forward hidden-state
        - 16-heads

~355M parameters trained on 2.5 TB of newly created clean CommonCrawl data in 100 languages


## Previous Works

- [Challenges for Toxic Comment Classification:
An In-Depth Error Analysis](https://www.aclweb.org/anthology/W18-5105/)

    This paper utilized English toxic comments data presented in [Kaggle Toxic Comment Classification Challenge 2018](https://www.kaggle.com/c/jigsaw-toxic-comment-classification-challenge/data) and gained insights from error analysis. They compared the performances of different classifiers and pre-trained word embeddings and evaluated using macro-averaged F1 score and ROC AUC. As a result, the best individual classifier was `bi-directional GRU network with Attention (embedded with FastText)` which obtained 0.783 F1-score and 0.983 ROC AUC, and the best classifier overall was `Ensemble Learning` which trained an ensemble with gradient boosting decision trees. This paper also stated that combining shallow learning approaches with Neural Networks would be highly effective.

- [Detecting and Classifying Toxic Comments](https://web.stanford.edu/class/archive/cs/cs224n/cs224n.1184/reports/6837517.pdf)

    This paper also used data from [Kaggle Toxic Comment Classification Challenge 2018](https://www.kaggle.com/c/jigsaw-toxic-comment-classification-challenge/data). They studied the effects of SVM, LSTM, CNN and MLP on classification with word and character-level embeddings. The best model they proposed was the `word-level Uni-LSTM model` which had a 0.886 F1-score.


- [Massively Multilingual Sentence Embeddings for Zero-Shot Cross-Lingual Transfer and Beyond](https://arxiv.org/pdf/1812.10464v2.pdf)

    This paper introduces a multi-lingual sentence representation trianed with Bi-LSTM enccoder with shared BPE vocabulary for 93 languages. When they tested the embeddinsg on Zero-Shot Transfer - one NLI system, their proposed embedding beated BERT uncased embedding in transfer performance. 

- [MultiFiT: Efficient Multi-lingual Language Model Fine-tuning](https://arxiv.org/pdf/1909.04761v1.pdf)

    This paper proposes Multi-lingual Fine-tuning which used an LSTM language model with tuned dropout hyperparameters (AWD-LSTM) and cross-lingual bootstrapping method to fine-tune the model based on its zero-shot predictions as pseudo labels. MultiFiT outperforms M-BERT in the zero-shot learning task.

- [Unsupervised Cross-lingual Representation Learning at Scale](https://arxiv.org/pdf/1911.02116.pdf)

    This paper shows that pretraining multilingual language models at scale leads to significant performance gains for a wide range of cross lingual transfer tasks. We train a Transformer based masked language model on one hundred languages, using more than two terabytes of filtered Common Crawl data.

    - Mixture of XML-R (handle low-resource languages) and mBERT
    - XLM-R is a multilingual model trained on 100 different languages. Unlike some XLM multilingual models, it does not require lang tensors to understand which language is used, and should be able to determine the correct language from the input ids.

- [Cross-lingual Language Model Pretraining](https://arxiv.org/pdf/1901.07291.pdf)

    Studies have demonstrated the efficiency of generative pretraining for English natural language understanding. And in this paper, the authors extend this approach to multiple languages and show the effectiveness of cross-lingual pretraining.

    - XLM is transformer-pretrained on these objectives: causal language modeling CLM (next token prediction), masked language modeling MLM, and translation language modeling TLM.
    - XLM-mlm-100-1280, the pretrained model that we are interested in is trained with MLM on 100 languages.
    - XLM-R was released several months after this paper and performs better than the checkpoints of XLM across the board.



## Evaluation

Since we are working on a binary classficiation problem (classifying non-toxic and toxic comments), our proposed evaluation metrics include macro-averaged F1-score and ROC AUC (Area Under the Receiver Operating Characteristic Curve).

## Results

1. MBERT 

    - Best Hyperparameters:

        model(input_ids = inputs, attention_mask = masks)
        batch_size = 32
        lr = 2e-6
        max_grad_norm = 1.0
        epochs = 10
        warmup_proportion = 0.1
        num_training_steps = len(train_dataloader) * epochs
        num_warmup_steps = num_training_steps * warmup_proportion
        hidden_size = 768
        data balance ratio: 0.2
    - Best AUC (valid): 0.6542
    - Best AUC (test in kaggle): 0.6526

2. XLM-RoBERTa
    - Best Hyperparameters:

        batch_size = 32
        lr = 2e-6
        max_grad_norm = 1.0
        epochs = 5
        warmup_proportion = 0.2
        num_training_steps  = len(train_dataloader) * epochs
        num_warmup_steps = num_training_steps * warmup_proportion
        hidden_size = 768
        data balance ratio: 0.2
    - Best AUC (valid): 0.7891
    - Best AUC (test in kaggle): 0.7779 

3. Visualization and Error Analysis (Coming next week)



## Challenges

1. Slow training process

    - The training data set is very large (~ 220,000 samples), so the training process is very slow even in GPU or TPU. Also, the resources for GPU an TPU are very limited in Google Colab and Kaggle. Therefore, we sub-sample around 60,000 training data to address this problem as well as the data unbalance problem to get our baseline estimation. After limiting the data size, training time for 1 epoch is about 15 minutes. Although limiting the data size accelerates the training process, the performance could be worse. Given the limited resources, we propose to tune hyperparameters using a smaller dataset first, and gradually add more train data to boost the performance. 

2. TPU Usage on Pytorch

    - As PyTorch package is not supporting TPU usage, we download the package `torch_xla` to address this problem. By using this package, we can set the device to TPU and accelerate our training process.  

3. Data Unbalance

    - Our training dataset is `jigsaw-toxic-comment-train.csv` which contains 223,549 samples. There are around 20,000 toxic comments and 200,000 non-toxic comments. It's obvious that our dataset is unbalanced. To slove this problem, we write a function to do downsampling which is picking all toxic comments and randomly selecting 20% non-toxic comments. So finally, we had around 60,000 comments for training.

4. Zero-shot Transfer Learning Problems

    - We only have the training data in English, while the validation and test data are from various languages, which means the decrease in training loss does not necessarily boost the performance in the validation or test set. To address this problem, we propose to:

        - Inject sampled multi-lingual data from the validation set to the training set to see if the performance improves
        - Try other language models, such as MultiFiT as mentioned in the Previous Work section
        - Try traditional bi-LSTM model with multilingual pretrained embeddings
        - Try to apply machine translation first through Google API to the validation set, and feed it back to the tuned BERT model 

5. Division of Labor
    - One of the challenges we faced this week was dividing work amongst the group. The two things we had to complete were this report and build our models and it's almost impossible to be involved in each aspect equally. For example, you can't have someone build half of the model and another to build the rest. If you had only one person build the model, the rest would go by the entire week without coding. The way we tried to get around this was to have everyone be in charge of one model. However, one of our proposed models, XLM was not very well-documented because of XLM-R's release. Having ended up with two models this week, we decided to have the member who was originally in charge of XLM attempt different implementations for our existing models, which will also be one of next week's tasks.

## Full Codes

Please see the full codes (run in Kaggle) [here](https://github.ubc.ca/jchn1202/COLX_585_JC_RL_SG/blob/RL/Milestone_2/RL_draft_2.ipynb)


## Resources

[Using TPU on PyTorch 1](https://www.kaggle.com/youhanlee/bert-pytorch-huggingface-tpu-version-xla)

[Using TPU on PyTorch 2](https://www.kaggle.com/cpmpml/tpu-sub-bs256-full-train)

