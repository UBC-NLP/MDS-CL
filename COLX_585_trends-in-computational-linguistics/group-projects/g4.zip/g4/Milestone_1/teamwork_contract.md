### Teamwork Contract

- We will distribute writing, model engineering, and presentation tasks equally among members.


- If the distribution of work is uneven, either in terms of difficulty or quantity, we will come up with a solution collaboratively.  


- Members are expected to meet 2 times, and spend a total of 20 hours combined on this project per week.


- Group meetings will be held over Zoom or Slack and important details are to be noted down in a Google drive document.


- Members will take turns summarizing the discussions for each meeting.


- The style of our group is going to be a democratic leadership with members taking turns to lead the group each milestone.


- After accomplishing each task, members should report their findings to the group.


- Members are expected to to their best.


- Since everyone is available at all times unless otherwise stated, they should easily be reachable.


- If any member is unable to attend a meeting, they should notify the rest of the team beforehand.

- Plagiarizing other groups, verbally abusing other members, and being unreachable for days on end is unacceptable behavior.


- Be nice. 