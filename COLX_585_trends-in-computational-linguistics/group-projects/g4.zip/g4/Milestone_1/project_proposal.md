# Project Proposal

## Introduction

[Jigsaw Multilingual Toxic Comment Classification](https://www.kaggle.com/c/jigsaw-multilingual-toxic-comment-classification/overview/description) is Kaggle competition launched by [Jigsaw](https://jigsaw.google.com/) and Google. This is a text classification task which aims to identify whether or not a comment is toxic. Toxicity here means rude, disrespectful or any inappropriate comments that will make people uncomfortable. In this project, our inputs are multilingual comments and we are expected to predict if it is toxic.

## Motivation and Contributions/Originality
Toxic comments have always been an issue online, because it only takes one to sour things and derail discussions. Given the prominence of social media nowadays, the growing impacts of toxic comments are becoming more concerning. For example, South Korean singer/actress Sulli's suicide was supposedly linked to depression caused by cyberbullying. Throughout her career, she had to constantly battle toxic, malicious comments directed towards her online. Unfortunately, Sulli's situation only came to light because of her status and it's only the tip of the iceberg. We hope to contribute by developing a system that is more robust than existing toxic-comment detecting models.


## Data

All the data is available on Kaggle. Click [here](https://www.kaggle.com/c/jigsaw-multilingual-toxic-comment-classification/data) to access the datasets. Also we have a copy of those datasets and uploaded them to Google Drive, here is the [link](https://drive.google.com/drive/folders/13cz8Xytgb1-QrSws4Q6cJvSzRTSC_thK?usp=sharing).

#### **jigsaw-toxic-comment-train.csv**. The dataset is made up of English comments from Wikipedia’s talk page edits. (**22,354** unique comments)

|id|comment_text|toxic|severe_toxic|obscene|threat|insult|identity_hate|
|--|------------|-----|------------|-------|------|------|-------------|
|1|0000997932d777bf|	Explanation Why the edits made under my username Hardcore Metallica Fan were reverted? They weren't vandalisms, just closure on some GAs after I voted at New York Dolls FAC. And please don't remove th...	|0	|0	|0	|0	|0	|0|

#### **jigsaw-unintended-bias-train.csv**. This is an expanded version of the Civil Comments dataset with a range of additional labels. (**1,876,468** unique comments)

|id|comment_text|toxic|severe_toxicity|obscene|identity_attack|insult|threat|....|
|--|------------|-----|------------|-------|------|------|--|---|
|1	|This is so cool. It's like, 'would you want your mother to read this??' Really great idea, well done!	|0.0|	0.0	|0.0|	0.0	|0.0|	0.0		|										

#### **sample_submission.csv** - a sample submission file in the correct format


|id |toxic|
|---|-----|
| 0 | 1.0 |

#### **test.csv** - comments from Wikipedia talk pages in different non-English languages. (**63,812** unique comments)


|id|content|lang|
|--|-------|----|
|0 |	Doctor Who adlı viki başlığına 12. doctor olarak bir viki yazarı kendi adını eklemiştir. Şahsen düzelttim. Onaylarsanız sevinirim. Occipital	|tr|


#### **validation.csv** - comments from Wikipedia talk pages in different non-English languages. (**8,000** unique comments)

|tr|es|it|
|--|--|--|
|38%|31%|31%|

|id|comment_text|lang|toxic|
|--|-------|----|---|
|1	|0	|Este usuario ni siquiera llega al rango de hereje . Por lo tanto debería ser quemado en la barbacoa para purificar su alma y nuestro aparato digestivo mediante su ingestión. Skipe linkin 22px ...	|es	|0|

#### **jigsaw-toxic-comment-train-processed-seqlen128.csv** - training data preprocessed for BERT

#### **jigsaw-unintended-bias-train-processed-seqlen128.csv** - training data preprocessed for BERT

#### **validation-processed-seqlen128.csv** - validation data preprocessed for BERT

#### **test-processed-seqlen128.csv** - test data preprocessed for BERT


## Engineering

For **computing infrastructure**, we can either use Kaggle's GPU which allows for up to 30 hours of usage per week, or Google Colab's GPU.

We will do text classification with BERT. Considering that it's a multilingual task, we also plan to use Machine Translation. On top of that, we will try to use Few or Zero shot Deepl Learning Methods.

## Previous Works

1. [Challenges for Toxic Comment Classification:
An In-Depth Error Analysis](https://www.aclweb.org/anthology/W18-5105/)

    This paper utilized English toxic comments data presented in [Kaggle Toxic Comment Classification Challenge 2018](https://www.kaggle.com/c/jigsaw-toxic-comment-classification-challenge/data) and gained insights from error analysis. They compared the performances of different classifiers and pre-trained word embeddings and evaluated using macro-averaged F1 score and ROC AUC. As a result, the best individual classifier was `bi-directional GRU network with Attention (embedded with FastText)` which obtained 0.783 F1-score and 0.983 ROC AUC, and the best classifier overall was `Ensemble Learning` which trained an ensemble with gradient boosting decision trees. This paper also stated that combining shallow learning approaches with Neural Networks would be highly effective.

2. [Detecting and Classifying Toxic Comments](https://web.stanford.edu/class/archive/cs/cs224n/cs224n.1184/reports/6837517.pdf)

    This paper also used data from [Kaggle Toxic Comment Classification Challenge 2018](https://www.kaggle.com/c/jigsaw-toxic-comment-classification-challenge/data). They studied the effects of SVM, LSTM, CNN and MLP on classification with word and character-level embeddings. The best model they proposed was the `word-level Uni-LSTM model` which had a 0.886 F1-score.


## Evaluation

Since we are working on a binary classficiation problem (classifying non-toxic and toxic comments), our proposed evaluation metrics include macro-averaged F1-score and ROC AUC (Area Under the Receiver Operating Characteristic Curve).

## Conclusion

The goal of this proposal is to explain why we chose this project and how we would like to approach it moving forward in terms of evaluation and engineering methods.