# COLX_585_JC_RL_SG
COLX585 Project Repo for Jon Chan CL, Rannie Lin and Shonna Gu

## [Jigsaw Multilingual Toxic Comment Classification](https://www.kaggle.com/c/jigsaw-multilingual-toxic-comment-classification/overview)

This project is a [Kaggle](https://www.kaggle.com/) Competition.


# Milestone 1

[Project Proposal](https://github.ubc.ca/jchn1202/COLX_585_JC_RL_SG/blob/master/Milestone_1/project_proposal.md)

[Teamwork Contract](https://github.ubc.ca/jchn1202/COLX_585_JC_RL_SG/blob/master/Milestone_1/teamwork_contract.md)

# Milestone 2

[Project Progress Report](https://github.ubc.ca/jchn1202/COLX_585_JC_RL_SG/blob/master/Milestone_2/Project%20Progess%20Report.md)

# Milestone 3

[Project Progress Report](https://github.ubc.ca/jchn1202/COLX_585_JC_RL_SG/blob/master/Milestone_3/Project%20Progess%20Report.md)

# Milestone 4

[Final Report](https://github.ubc.ca/jchn1202/COLX_585_JC_RL_SG/blob/master/Milestone_4/Jigsaw%20Multilingual%20Toxic%20Comment%20Classification.pdf)

[Presentation Slides](https://github.ubc.ca/jchn1202/COLX_585_JC_RL_SG/blob/master/Milestone_4/Jigsaw%20Multilingual%20Toxic%20Comment%20Classification.pptx)
