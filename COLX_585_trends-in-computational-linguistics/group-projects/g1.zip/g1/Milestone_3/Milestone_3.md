Milestone\_3
================
Naga Sirisha, Jon, Pan
12/04/2020

### Introduction

Our project is the “Racism detection of tweets in the context of
COVID-19”. This is a “classification task” of the intent of the tweet.
The task involves that we create a dataset for the tweets and split the
dataset into training, development and testing dataset. We annotated
roughly 1000 tweets into “Racist” and “Non-racist” tweets. We will use
this tagged data to train model and classify the rest of the tweets. The
annotation guidelines will be discussed below.

**Motivation:**

The motivation for pursuing this is that the present unprecedented times
of the pandemic of COVID-19, there is a plethora of negative comments
that are circulated in the social media platform. This propagation of
negative comments which are directed towards a specific ethnic group
leads to harmful impacts in the society. Our motivation is to build a
model that can identify such tweets that contains racist comments. This
could be incorporated to “moderate” the racist comments of some
platforms likeblogs or news websites.

Our contribution of the model will be significant since it is
domain-specific “COVID-19”.

<u>Our Definition of racism:</u> Negative comments that are subjected
towards a specific ethnic group.

**Data:**

  - We are using the data by scraping the famous social-media platform
    “Twitter”. We scraped half of our dataset from Twitter using the
    code we built, the tweets are fetched of the users from across
    different parts of the world.
  - The rest of the part of the dataset is used from the tweets provided
    by the teaching team.
  - The online social-media platform Twitter, according to
    [this](https://www.omnicoreagency.com/twitter-statistics/) platform
      - User profiles: 48.35 million Twitter users are American, 35.65
        million are Japanese, 13.9 million are Russian and 13.7 million
        are from the U.K. We will only collect English tweets, so we
        expect the majority of the users to be from North America and
        the United Kingdom.
      - Tweet length: maximum length is 280 characters, however Twitter
        reports less than 1% of tweets reach the maximum and only 12%
        reach 140 characters
  - We scraped some particular hashtags which we think might be useful
    in extraction of the racist comments in order to mitigate the class
    imbalance in the dataset. This an application of “distant
    supervision” of unlabelled data for Information retreival.
  - So far we have annoted 1000 tweets manually, we have done this
    because it was difficult to find already annotated data online, we
    have found one discussed in
    [this](https://www.aclweb.org/anthology/W16-5618.pdf) paper, but it
    has tweet\_ids instead of the tweet\_text and we plan to use this
    data set as well in the upcoming milestones if time allows.
  - Final dataset will be a minimum of 1000 tweets, with additional
    tweets to be annotated depending on time requirement. Initial
    experiments will determine how much more data is required.
    Annotation methodology

| Tweet Information           | Count  |
| --------------------------- | :----: |
| Extracted Tweet Count       | 50,000 |
| Staff side Tweet Count      | 25,000 |
| Final Annotated Tweet Count |  1000  |

**Annotators**:

  - Pandramishi Naga Sirisha
  - Jon T.K. Chan

We will see the CNN model and BERT model performance so far with this
data and if the performance is poor, will consider doing a
inter-annotator agreement.

**Annotation guidelines**:

For this model, we are considering the binary classification task
between racist and non-racist tweets. Tweets with ambiguous content
(annotators are unsure if the tweet is racist or hateful) will be
classified as ‘non-racist’ for the purposes of this project. Addition of
a third ‘ambiguous’ label is possible for future improvements of this
project.

Tweets will be labelled manually by the project team using the following
criteria.

**Guidelines for annotating the tweet as “Racist” :**

  - Racist slang is used

> fuck off china causing harm to the world no china disgusting china
> dirty china covid19=made in china \#NoChina \#fuckchina \#dirtychina
> \#china \#ChinaVirus \#ChinaLiedAndPeopleDied \#China\_is\_terrorist
> \#ChinaCoronaVirus \#ChinaIsAsshoe \#harmful \#pleasefuckoff
> \#dontbuychinese <https://t.co/EYS1D892Dy>

  - Tweet content targets a particular ethnic/cultural group and refers
    to them in a negative light.
  - In the context of COVID-19, Tweet includes statements that
    exaggerate or assigning intention towards China, Chinese or a
    particular country.
  - Unfounded hateful tweets are racist.

> Never believe China\! \#ChinaVirus \#ChinaLiedAndPeopleDied
> <https://t.co/yDQUpWk1hm> - Hatefulness towards communism which is
> baseless. @tedcruz Disgusting communist party \#ChineseVirus
> \#ChinaLiedAndPeopleDied <https://t.co/ejarK29IF7>

**Guidelines for annotating the tweet as “Non-racist” :**

  - Generic informational tweets or reporting news articles.

> Here’s how \#ChinaLiedAndPeopleDied: 1. China hid reports of the virus
> for weeks. 2. China targeted the whistle-blowers. 3. China destroyed
> test samples of patients. 4. China lied to the world about the
> seriousness of the situation & death toll. \#ChineseVirus
> <https://t.co/qSFVXLSb1a>

  - Hatred towards a particular person is not considered as racism. Ex:
    Xi-Ping

> Partners in crime WHO cheif @DrTedros and China’s president
> \#XiJinping  
> \#ChineseVirusCorona \#XijinpingVirus \#COVID19 \#Covid\_19
> \#coronavirus \#corona \#China \#ChinaLiedAndPeopleDied
> <https://t.co/uRFSkrEZfI>

  - Hatefulness or criticism towards a political party, this is seen as
    criticizing a Government and may not be generally tagged as racist.
    Ex: Chinese Communist Party, Chinese Government
  - Text that is expressing negative emotion without assigning blame to
    an ethnic or racial group.
  - Hateful tweet where the only racist part is the hashtag and the
    hashtag is not being used in context with the rest of the tweet text
  - Tweets that could be racist, but reference a potentially racist
    external media (link to video, meme, etc) as we are not processing
    any videos or images.

**Resolving ambiguity, sarcasm and dog-whistle type racism**

  - For initial trials, tweets that are ambiguously racist will be
    labelled as non-racist. The model’s current iteration is concerned
    with identifying tweets that are obviously racist based on text
    content, and any ambiguity introduced by sarcasm or word use will
    not be considered until later milestones.

> China Warmth❤️ Please STOP scolding China🙅🏻 ♀️ You can not love, but
> please do not hurt❤️ China is also our most precious treasure❤️
> Love\&Peace🙏🏻 \#China \#ChineseCoronaVirus \#ChinaVirus \#ChinaMustPay
> \#ChinaLiedAndPeopleDied \#ChinaIsAsshoe \#China\_is\_terrorist
> \#ChinaWuhanVirus <https://t.co/9FoaeSPCXc>

  - When assigning annotations, hashtags will be considered in context
    with tweet content. When hashtags are used as part of the tweet
    sentence, combined interpretation will be considered when
    determining between racist and non-racist. However, tweets will be
    labelled non-racist if the only racist component is the mentioned
    hashtags.

> @ChinaDaily Better hashtags…. \#ChinaLiedPeopleDied
> \#ChinaLiedAndPeopleDied \#ChinaVirus <https://t.co/Jia3gqBPlB>

  - For this model, certain supplementary tweets will be ignored. URLs
    and mentions of other Twitter users will not be considered any
    different from other tokens of the text. This means that if the
    tweet cannot be deemed racist using only the tweet text (must be
    viewed as an image or supplementary article), it will be labelled as
    ‘non-racist’.

### Addressing the feedback from Milestone\_2

1.  Initial tests that we conducted in Milestone\_2 encountered
    significant class imbalance problems. Less than 100-150 tweets were
    labelled as racist, and both CNN and BERT models would default to
    labelling ‘non-racist’ for all tweets when predicting on the train
    set. This was addressed by modifications to weight parameter in loss
    function, placing harsher penalization on incorrect predictions of
    the smaller class.

2.  Committed the twitter extraction code “Twitter\_extraction.ipynb”
    [here](https://github.ubc.ca/chan111j/group_1_trends_project/blob/master/Milestone_2/Twitter_extraction.ipynb)

3.Initial tweetset of 1000 tweets was split into 80% training, 10% dev,
and 10% dev. Considering the limited amount of annotated data, model
experiments will focus on optimizing performance with smaller datasets.
Such a case will prove useful in cases similar to the COVID-19 outbreak,
where NLP analysis must be carried out without large amounts of
annotated data within the specified domain.

4.  Fixed

5.  We envision building our model in such a way that it can be useful
    to filter/identify racist tweets or comments that will be posted on
    blogposts or news websites related to COVID-19.

6.  Statistical reports that of the top 10 countries with the largest
    twitter presence, 3 of them are predominently english countries. The
    US has the largest at approximately 59.35 million users, with the UK
    and Canada contributing 16.7 million and 6.88 million users,
    respectively. the US is of particular interest, as this country’s
    leader was instrumental in coining the phrase ‘china virus’ and
    fueling much of the rhetoric behind the racist tweets and hashtags
    to be targeted in this report. It would make sense that tweets
    resulting from the US have increased potential to hold some of the
    racist sentiments posed by it’s leader. For these reasons, english
    was selected as the language to target for collecting and analyzing
    tweets. source:
    <https://www.statista.com/statistics/242606/number-of-active-twitter-users-in-selected-countries/>

We have initially considered the option of using Weibo,a
social-networking platform to extract the posts in Chinese language. But
there were several short-comings that we identified upon discussion
within our team. One, there was no standard API that was published to
ethically scrape data from Weibo. Two, finding annotators for Chinese
language would be a barrier as one of the member in our team doesn’t
understand Chinese. Other languages could’ve been considered as well but
given the limited time we dropped the idea.

7.  Collection of tweets for this project was carried out to supplement
    the tweets provided by teaching staff. Due to the size of the tweets
    already provided, coupled with the limited annotation resources
    available for this project, project members decided that tweets from
    only one hashtag was sufficient.

We have done some initial vetting of the tweets from several hashtags.
Finally we arrived at a consensus that as compared to a generic hashtag
like \#COVID-19, this particular hashtag contained a higher ratio of
tweets which were racist. Hence, there was inclination to download these
tweets and work with them in order to obtain a higher percentage of
tweets that can be examples of racist tweets.

8.  Twitter has limitation that we will be able to download data that is
    maximum 7 days older.

9.  As mentioned in the ‘previous works’ section of this report and
    Milestone\_2 report, ambiguity will likely cause some issue with
    determining racist and non-racist labels. Some tweets could be seen
    as being moreso off-colour humour instead of outright racism, while
    other tweets could be seen as racist when the text is moreso
    targeting a specific government organization instead of an ethnic
    group. For this reason, a third label of ‘ambiguous’ may need to be
    added in future improvements for this project.

<!-- end list -->

  - We planned to re-annotate the data in case of poor performance of
    the model by redefining the annotation guidelines.
  - We also planned to get a third annotator do the annotations for the
    existing tweets and keep some initial tweets which are obviously
    racist and non-racist.
  - We should also change the model from a binary classifier to a
    multi-class classifier in this case.

<!-- end list -->

10. Yes, we acknowledge that in case we implement distant supervision we
    need to remove the hashtag in the pre-processing. As of yet, we
    haven’t implemented this.

11. We have not eliminated the mentions and urls from the tweets. As
    mentions could be part of the tweet text. We have put a cap on the
    percentage of a tweet that has a hyper link.

12. For both CNN and BERT model experiments, tokenization of tweets was
    carried out using the Spacy english tokenizer.

13. Fixed

14. To be presented in Final project report.

15. We will work on it if time allows. Thank you for the suggestion.

### Methods and Engineering

**Model**

  - Zhongyu Pan

So far we have been trying CNN text classification model and BERT text
classification model introduced in the lecture. We adapted and
customized the code from tutorials towards our data, and we added the
`predict` function to obtain the predictions of test set.

How did we fix the class imbalance problem:

Note that in our data the proportion of rasicst and non-rascist tweets is around 1:9, which contributes to serious class imbalance problem. The consequence of class imbalance problem is that our model turns out to be only predicting "non-rascist" and still obtains high accurracy. But we don't want our model to be this "naive"! Therefore, we read this [article](https://discuss.pytorch.org/t/what-is-the-weight-values-mean-in-torch-nn-crossentropyloss/11455/2) and found out that a way to address the class imbalance problem is to pass `weight` argument to the NLLLoss. After some tuning experiments we set the weight to be `[1, 9]` and it seems to give us a decent result by predicting both types of tags at the same time.

About data preprocessing: There were empty labels inside the data and the
model used to interpret the data as having 3 target labels, we used
`df.info` function to find the null values and replaced them with one of
the tags.

**Hyperparameters/Model details**

  - Embedding dimension: 300

  - Output channels (convolutional layer 1): 32

  - Output channels (convolutional layer 2): 32

  - Output channels (convolutional layer 3): 32

  - Kernal region size (convolutional layer 1): 2

  - Kernal region size (convolutional layer 2): 3

  - Kernal region size (convolutional layer 3): 4

  - Dropout rate: 0.5

  - Learning rate: 0.01

  - Optimizer: Adam

  - Loss function: Cross entropy loss

  - Class weight - ‘racist’ tag: 9

  - Class weight - ‘non-racist’ tag: 1

  - Output size: 2 (binary classification)

  - Resulting trainable paramaters: 531,590

**Model Steps**

0.  Define required items: spacy tokenizer, train/dev/test splits, and
    vocab dictionaries for inputs and predictions.

1.  Tweets are tokenized using Spacy english tokenizer

2.  Tweet token sequences are passed to an embedding layer, creating 300
    dimensional word embedding vectors.

3.  Embeddings are passed to three convolutional layers, each has 32
    output channels with 2 kernals of different region sizes (2, 3, and
    4, respectively).

4.  Feature vectors are generated from passing convolutional layer
    outputs into 3 max pooling layers.

5.  Feature representations are concatenated and passed to a dropout
    layer (dropout rate: 0.5)

6.  Feature representations are passed to a softmax layer for final
    prediction values.

7.  Prediction tags are found using prediction values and target
    dictionary

### Evaluation:

We will use present the classification report the evaluation of the
system. We in the upcoming weeks pick this because our task is a
classification problem and perhaps we will run into a class imbalance
problem because of the inherent nature of the problem and the data, that
most tweets that are published are **not racist** according to the
*“Pollyanna Hypothesis”* of data.

**Evaluation on sample data for tentative CNN model:**

In our tentative CNN model, we calculated `train_loss`,
`validation_loss`, `validation_accuracy` and `validation_f1_score` under
each training epoch to see how well the model performance is.

### Challenges

**Ambiguous Tweets classification :** relies on human judgement of what
is racist.

**Limited annotated data :** Significant time goes into preparing
appropriate dataset before model can acutally be built

**Extraction of tweets :**

  - Twitter has a limit of just 150 API calls that any user can make in
    a 15mins window and each API call has a limit of downloading a
    certain number of tweets. Post this point the session will be
    terminated.
  - This adds an overhead to download more 150 tweets, and we make
    another new API call, the API fetches the same latest 150 tweets
    from that time. This may lead to duplication of tweets .
  - Hence we devised the following algorithm to downloaded tweets to
    overcome this issue:

<!-- end list -->

1.  Read the config file

2.  Read and validate the configurations

3.  Authenticate the Twitter API user

4.  Run Steps 5 to end, if downloaded tweets \<= maxTweets

5.  Use Twitter API call and Tweepy’s Cursor to search for posts with
    \#coronavirus. We can filter out retweets, set language in the
    search.

6.  From the returned tweets data in that particular API call, we will
    extract:
    
      - text - tweet.full\_text
      - date created - tweet.created\_at
      - location - tweet.user.location

7.  Convert the output of (5.) into a pandas dataframe

8.  Clean and preprocess the dataframe. For example, the month and day
    of the post should be in its own column and the location should be
    by country.

9.  Write/append the dataframe to a csv file.

10. Calculate the remaining tweets to be downloaded, the minid (oldest
    id of the tweet in the previous API call) and write it back to
    config file

11. Check if TIME\_OUT (twitter limit of 150 API calls for 15mins) is
    reached:
    
      - If yes, sleep for 15 mins
      - Else, continue to step . 5

12. Return to (4.) to conduct more searchs if necessary.

**Restartability of the code:**

\-To download more number of tweets, the code is written such that The
code is able to restart and automatically resume from the spot that it
has previously stopped. This is achieved because in the code.

  - We track the tweet\_id of the tweet that was the oldest.

  - After a downloading tweetCount number of tweets we write them to the
    output file (this is opened in “append” mode).

  - At the same time we update the config file with the remaining tweets
    to be downloaded as (maxTweets)-(downloaded\_tweets) and minid =
    oldest\_tweet\_id

  - Thus when we restart the system again the code is able to fetch the
    updated tweet\_id and maximum number of tweets from this updated
    config file (from the previous run) to fetch and resumes the
    download again.

### Results

The initial `train_loss`, `validation_loss`, `validation_accuracy` and
`validation_f1_score` for CNN model are 0.4831, 0.4269, 0.8864, 0.4699.

The initial `train_loss`, `validation_loss`, `validation_accuracy` and
`validation_f1_score` for BERT model are 0.4516, 0.3586, 0.8864, 0.4699.

Based on the above result we assume the models are predicting everything
as “non-racist” because of the data imbalance problem–we only have a
very small number of “racist” data.

Previously we have tried using a small amount of data set where ‘racist’
tags consists of 40% of the data, and the two models did predict
‘racist’ labels. Therefore, the next step we will try to do is to
find more ‘racist’ data or at least raise the percentage of ‘racist’
data in our data set, so that the models will not naively “guess”
“non-racist” tag for all the tweets.

Through further experimentation, the Convolutional Neural Network model
was found to be the model that performed best on the racism dataset. For
this project, CNN experiments were carried out on Google colab to
utilize cloud GPU when training the model. Tweet data is stored in tsv
files after having been manually divided into train, dev, and test sets
using 80/10/10 split percentage.

As mentioned previously, model was trained on 800 manually annotated
tweets. After 10 epochs, maximum validation accuracy was found to be
83.64% in Epoch 10. Maximum F1-score was 61.01% after epoch 2. Note that
class imbalance issues were addressed by assigning a 9:1 error weight to
racist tags when calculating loss (previous experiments showed that the
model would default to classifying all tweets as non-racist if class
weights were not specified).

### Previous Work

  - Kwok and Wang (2013) outlines issues with a baseline non-RNN model
    that this project can seek to overcome. The paper used a Naive Bayes
    classifier to classify racist and non-racist tweets using around
    24,000 tweets in a balanced dataset. This model was only capable of
    identifying Unigram occurrences of derogatory words, meaning that no
    context could be established in terms of how words would interact or
    be used in non-intentional ways. Accuracy in this model was around
    76%, suggesting that an RNN model used on the similar dataset would
    be able to achieve increased performance.

  - MAcAvaney et. al. (2019) used a Multiview SVM model with C = 0.1 to
    identify hate speech online. Evaluation methods include accuracy and
    macro-averaged F1 score, which we plan to use for our model as well.
    The paper also used a BERT model, which could potentially be part of
    our solution depending on feasibility of training. Challenges that
    the paper mentions include ambiguous context of words that appear to
    be hate speech (person A may be tagged as delivering hate speech
    even if they are quoting and condemning the hate speech from person
    B). Specifics of the RNN structure will be explored when building
    this project’s model.

  - Real-world applications of the model must be considered when
    evaluating model performance. Contextual issues with hate speech
    modelling is further reported by The Observer, which explains how
    machine learning models incorrectly label text that is used in
    relatively innocent contexts tagging the user as being ‘hateful’
    when using particular vocabulary. This can result in the
    misidentification of authors as spreading ‘hate speech’ when a human
    would deem the tweet as innocent.

  - Gamback and Sikdar (2017) has previously used CNN models on 4 label
    classification. Using a set of approximately 6500 tweets, models
    were trained to classify for 4 labels: Rasicm, Sexism, Both (racism
    and sexism), and non-hate-speech. 4 CNN models were tested to
    evaluate effect of word2vec and character N-grams on model
    performance. These models were compared against a baseline logistic
    regression classifier in terms of precision, recall, F1-score. Using
    CNN and word2vec embeddings, The highest F1-score was found to be
    78.3%. Embeddings using 4 character grams were tested in 2 other
    models, though Fscore was not improved. It was noted that when
    compared to baseline models (logistic regression), Fscore was
    improved but recall was better than all of the CNN models. For this
    project, members will note that improvements in F1-score may not
    result in an improvement in all metrics.

  - Paraschiv and Cercel (2019) used several BERT models to classify
    tweets in german. Classification tasks include binary classification
    (offensive vs non-offensive) and fine grained classifcation of
    tweets(determining between profanity, insult, and abuse).
    Classification was done using a BERT model (12 transformer blocks,
    12 attention heads) with two pretraining phases. The model was
    pre-trained on three corpora before tests were conducted, suggesting
    that this project may be interested in looking into pretraining the
    model given the limited classification data. Both tasks were
    performed on a tweet set of 12,500 tweets, and best resulting
    F1-scores were 76.95% and 70.84% for the two classifcation tasks
    respectively.

### References

  - Cao, S. (2019). Google’s Artificial Intelligence Hate Speech
    Detector Has a ‘Black Tweet’ Problem. The Observer. Retrieved on
    April 4, 2020 from
    <https://observer.com/2019/08/google-ai-hate-speech-detector-black-racial-bias-twitter-study/>

  - Gambäck, B., & Sikdar, U. K. (2017, August). Using convolutional
    neural networks to classify hate-speech. In Proceedings of the first
    workshop on abusive language online (pp. 85-90).

  - Kwok, I. and Wang, Y. (2013). Locate the Hate: Detecting Tweets
    against Blacks. AAAI. Retrieved on April 4, 2020 from
    <https://www.semanticscholar.org/paper/Locate-the-Hate%3A-Detecting-Tweets-against-Blacks-Kwok-Wang/db5511e90b2f4d650067ebf934294617eff81eca>

  - MacAvaney S, Yao H-R, Yang E, Russell K, Goharian N, Frieder O
    (2019) Hate speech detection: Challenges and solutions. PLoS ONE
    14(8): e0221152. <https://doi.org/10.1371/journal.pone.0221152>.
    Retrieved on April 4, 2020 from
    <https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0221152>

  - Paraschiv, A., & Cercel, D. C. (2019). UPB at GermEval-2019 Task 2:
    BERT-Based Offensive Language Classification of German Tweets. In
    Preliminary proceedings of the 15th Conference on Natural Language
    Processing (KONVENS 2019). Erlangen, Germany: German Society for
    Computational Linguistics & Language Technology (pp. 396-402). ©
    2020 GitHub, Inc.
