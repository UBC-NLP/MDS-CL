Milestone\_4\_report
================
Naga Sirisha, Jon, Pan
24/04/2020

# Racism Detection for COVID-19 Twitter Data

## Pandramishi Naga Sirisha, Zhongyu Pan, Jonathan T.K. Chan

### Abstract

Online expression is more prevalent now than ever. With the advent of
modern technologywhere news travels at lightning speed, people are quick
to express their opinion online. How-ever, several people choose to
express their thoughts on social media in a violent, uncivilized,and
racist fashion. While the debate rages on about whether these social
media giants shouldbe held accountable to prevent the spread of
unfounded hatred and offensiveness on theirplatforms, it is essential to
understand whether our models are strong enough to detect thishatred in
the first place. Hence, we built a model to detect racism on Twitter. In
the context of COVID-19, there has been a lot of hate-speech about who
is responsible for the virus, most ofit directed at China. We have used
a dataset of 1000 tweets to train, develop, and test a modelto detect
racism in these tweets. Upon successful modeling using both BERT and CNN
(Con-volutional Neural Networks), our results showed that the better
performing model (CNN) cansuccessfully flag racist tweets. Further
research on this front could lead to powerful text flag-ging models.

### Introduction

It has never been easier to express one’s opinion on any topic. The
rapid advancement oftechnology, social networking, and internet
connectivity together are breaking communication barriers all over the
world. Now, anyone who wants to be heard can make themselves heard.
Social media platforms such as Twitter, Facebook, and Instagram are key
contributors to this generation of expressionism.

While the freedom of speech that comes with all these factors appears
nice, manypeople use the opportunity to spark and incite hatred based on
religion, ethnicity, sex, race,etc. Certain groups get together on
social media to promote an environment filled with vicious thoughts and
hatred. While the accountability of the social media giants is still in
question, efforts need to be made to build models that are capable of
detecting this hatred in the first place. Data Science and computational
linguistics are making leaps and bounds in thefield of Natural Language
Processing (NLP). NLP is at a level where we can build highly
so-phisticated models that can accurately analyze language sentiments.

Currently, the world is going through tough times. The COVID-19 pandemic
hastaken the world by storm. The economies are crumbling, people are
losing jobs and peopleare handling stress at an unprecedented level.
With most of the world stuck at home, the expression on social media has
sky-rocketed. Everybody from country presidents to healthcare workers is
expressing their thoughts on the impact of the situation and the
potential solutions.Additionally, many people are expressing their
opinions on China’s initial handling of the situation. While some people
are civilized and are expressing their honest fact-based opinion,others
are just spreading vile hatred filled with racism.

Hence, we endeavor to build a model that is capable of detecting racism
on Twitter. To builda model which can accurately flag racism based on
the definition we provide, a database of 1000 tweets have been used. We
define racism as follows:

  - Negative comments that are directed towards a specific ethnic group

  - Comments which show unfounded and baseless hatred

  - Any tweets which exaggerate or assign the intention of COVID-19 to
    China or Chinese people

  - Any tweets which target communism baselessly

### Related Work

  - Kwok and Wang (2013) outlines issues with a baseline non-RNN model
    that this project can seek to overcome. The paper used a Naive Bayes
    classifier to classify racist and non-racist tweets using around
    24,000 tweets in a balanced dataset. This model was only capable of
    identifying Unigram occurrences of derogatory words, meaning that no
    context could be established in terms of how words would interact or
    be used in non-intentional ways. Accuracy in this model was around
    76%, suggesting that an RNN model used on the similar dataset would
    be able to achieve increased performance.

  - MAcAvaney et. al. (2019) used a Multiview SVM model with C = 0.1 to
    identify hate speech online. Evaluation methods include accuracy and
    macro-averaged F1 score, which we plan to use for our model as well.
    The paper also used a BERT model, which could potentially be part of
    our solution depending on feasibility of training. Challenges that
    the paper mentions include ambiguous context of words that appear to
    be hate speech (person A may be tagged as delivering hate speech
    even if they are quoting and condemning the hate speech from person
    B). Specifics of the RNN structure will be explored when building
    this project’s model.

  - Real-world applications of the model must be considered when
    evaluating model performance. Contextual issues with hate speech
    modelling is further reported by The Observer, which explains how
    machine learning models incorrectly label text that is used in
    relatively innocent contexts tagging the user as being ‘hateful’
    when using particular vocabulary. This can result in the
    misidentification of authors as spreading ‘hate speech’ when a human
    would deem the tweet as innocent.

  - Gamback and Sikdar (2017) has previously used CNN models on 4 label
    classification. Using a set of approximately 6500 tweets, models
    were trained to classify for 4 labels: Rasicm, Sexism, Both (racism
    and sexism), and non-hate-speech. 4 CNN models were tested to
    evaluate effect of word2vec and character N-grams on model
    performance. These models were compared against a baseline logistic
    regression classifier in terms of precision, recall, F1-score. Using
    CNN and word2vec embeddings, The highest F1-score was found to be
    78.3%. Embeddings using 4 character grams were tested in 2 other
    models, though Fscore was not improved. It was noted that when
    compared to baseline models (logistic regression), Fscore was
    improved but recall was better than all of the CNN models. For this
    project, members will note that improvements in F1-score may not
    result in an improvement in all metrics.

  - Paraschiv and Cercel (2019) used several BERT models to classify
    tweets in german. Classification tasks include binary classification
    (offensive vs non-offensive) and fine grained classifcation of
    tweets(determining between profanity, insult, and abuse).
    Classification was done using a BERT model (12 transformer blocks,
    12 attention heads) with two pretraining phases. The model was
    pre-trained on three corpora before tests were conducted, suggesting
    that this project may be interested in looking into pretraining the
    model given the limited classification data. Both tasks were
    performed on a tweet set of 12,500 tweets, and best resulting
    F1-scores were 76.95% and 70.84% for the two classifcation tasks
    respectively.

### Data

**Tweet Collection**

| Tweet Information           | Count  |
| --------------------------- | ------ |
| Extracted Tweet Count       | 76,700 |
| Staff side Tweet Count      | 25,000 |
| Final Annotated Tweet Count | 1000   |

Initial collection of tweets involved tweets from two sources. The first
tweet set was provided by the course teaching staff, comprising over
76,600 tweets stored in a .txt file. The second tweet set was collected
by the project team members by scraping tweets related to the hashtag
\#ChinaLiedAndPeopleDied. This hashtag was deemed one of the hashtags
that would yield a reasonable number of negative and potentially racist
tweets. In the early weeks of this project, approximately 25,000 tweets
were collected and stored in a csv file.

Several issues with the tweet data had to be addressed before tweets
were ready for use. In examining the tweets, many of them contained the
same content (actual words that contain the main message o fthe tweet).
Both data sources collected a sizable amount of Retweets (tweets that
were shared from another user) and tweets that did not contain useful
text (ex: tweets consisting of only a URL link and hashtags/mentions of
other accounts). Additionally, hashtags were to be treated carefully.
Tweets were unlikely to be useful if most of the text was taken up by
hashtags or mentions of other accounts. At the same time, some tweets
used hashtags as part of the tweet message itself (Example tweet: “we
all know that \#ChinaLiedAndPeopleDied”).

Based on observations of real-time Twitter data, several keywords were
brainstormed by the project team. These words were either hashtags that
were likely to contain racist tweets, or were related to the topic of
COVID-19 and negative Twitter sentiment related to race. The words that
were deemed important is listed below:

`["chinavirus", "chinesevirus", "chinaliedandpeopledied", "covidiots",
"china","chinese", "chink", "asian", "chinaliedpeopledied",
"wuhanvirus", "ccpvirus","chinesebioterrorism", "boycottchina",
"coronavirustruth", "ccp_is_terrorist", "wuflu", "chinesewuhanvirus",
"keepamericagreat", "maga", "makeamericagreatagain", "trump2020",
"holdchinaaccountable", "makechinapay", "racist", "racism", "ccp",
"wholiedpeopledied", "crime", "propoganda", "communist", "communism"]`

The project team wanted to target tweets that were novel and were likely
to contain messaging that was relevant to COVID-19, to that end, tweets
meeting the following criteria were discarded: -Tweet was a retweeted
tweet (tweet text beginning in “RT”) -Tweets was incomplete (full text
was not displayed - ending in ellipses) -Tweet URL made up more than 50%
of tweet characters -Tweet hashtags and mentions make up more than 75%
of tweet characters -Tweet contains a word or hashtag related to
COVID-19 or related topics (lowercased words in tweet contains one or
more words in the list above)

Roughly 500 tweets were collected from the two tweet sources in order to
create the final annotated set.

**Final dataset**

| Tweet split | Total | Count - ‘racist’ | Count - ‘non-racist’ |
| ----------- | ----- | ---------------- | -------------------- |
| Train       | 701   | 119              | 582                  |
| Dev         | 220   | 25               | 195                  |
| Test        | 72    | 18               | 54                   |

For this model, the data was prepared for a binary classification task
between racist and non-racist tweets. Tweets with ambiguous content
(annotators are unsure if the tweet is racist or hateful) will be
classified as ‘non-racist’ for the purposes of this project. Due to
limated annotation resources, an interannoator agreement was excluded
for this iteration of the project.

**Annotation Method**

Tweets will be labelled manually by the project team guidelines.
Examples found from data are attached below.

  - Racist slang is used

> fuck off china causing harm to the world no china disgusting china
> dirty china covid19=made in china \#NoChina \#fuckchina \#dirtychina
> \#china \#ChinaVirus \#ChinaLiedAndPeopleDied \#China\_is\_terrorist
> \#ChinaCoronaVirus \#ChinaIsAsshoe \#harmful \#pleasefuckoff
> \#dontbuychinese <https://t.co/EYS1D892Dy>

  - Tweet content targets a particular ethnic/cultural group and refers
    to them in a negative light.
  - In the context of COVID-19, Tweet includes statements that
    exaggerate or assigning intention towards China, Chinese or a
    particular country.
  - Unfounded hateful tweets are racist.

> Never believe China\! \#ChinaVirus \#ChinaLiedAndPeopleDied
> <https://t.co/yDQUpWk1hm> - Hatefulness towards communism which is
> baseless. @tedcruz Disgusting communist party \#ChineseVirus
> \#ChinaLiedAndPeopleDied <https://t.co/ejarK29IF7>

**Guidelines for annotating the tweet as “Non-racist” :**

  - Generic informational tweets or reporting news articles.

> Here’s how \#ChinaLiedAndPeopleDied: 1. China hid reports of the virus
> for weeks. 2. China targeted the whistle-blowers. 3. China destroyed
> test samples of patients. 4. China lied to the world about the
> seriousness of the situation & death toll. \#ChineseVirus
> <https://t.co/qSFVXLSb1a>

  - Hatred towards a particular person is not considered as racism. Ex:
    Xi-Ping

> Partners in crime WHO cheif @DrTedros and China’s president
> \#XiJinping  
> \#ChineseVirusCorona \#XijinpingVirus \#COVID19 \#Covid\_19
> \#coronavirus \#corona \#China \#ChinaLiedAndPeopleDied
> <https://t.co/uRFSkrEZfI>

  - Hatefulness or criticism towards a political party, this is seen as
    criticizing a Government and may not be generally tagged as racist.
    Ex: Chinese Communist Party, Chinese Government
  - Text that is expressing negative emotion without assigning blame to
    an ethnic or racial group.
  - Hateful tweet where the only racist part is the hashtag and the
    hashtag is not being used in context with the rest of the tweet text
  - Tweets that could be racist, but reference a potentially racist
    external media (link to video, meme, etc) as we are not processing
    any videos or images.

**Resolving ambiguity, sarcasm and dog-whistle type racism**

  - For initial trials, tweets that are ambiguously racist will be
    labelled as non-racist. The model’s current iteration is concerned
    with identifying tweets that are obviously racist based on text
    content, and any ambiguity introduced by sarcasm or word use will
    not be considered until later milestones.

> China Warmth❤️ Please STOP scolding China🙅🏻 ♀️ You can not love, but
> please do not hurt❤️ China is also our most precious treasure❤️
> Love\&Peace🙏🏻 \#China \#ChineseCoronaVirus \#ChinaVirus \#ChinaMustPay
> \#ChinaLiedAndPeopleDied \#ChinaIsAsshoe \#China\_is\_terrorist
> \#ChinaWuhanVirus <https://t.co/9FoaeSPCXc>

  - When assigning annotations, hashtags will be considered in context
    with tweet content. When hashtags are used as part of the tweet
    sentence, combined interpretation will be considered when
    determining between racist and non-racist. However, tweets will be
    labelled non-racist if the only racist component is the mentioned
    hashtags.

> @ChinaDaily Better hashtags…. \#ChinaLiedPeopleDied
> \#ChinaLiedAndPeopleDied \#ChinaVirus <https://t.co/Jia3gqBPlB>

  - For this model, certain supplementary tweets will be ignored. URLs
    and mentions of other Twitter users will not be considered any
    different from other tokens of the text. This means that if the
    tweet cannot be deemed racist using only the tweet text (must be
    viewed as an image or supplementary article), it will be labelled as
    ‘non-racist’.

### Methods

**Baseline**

Baseline model was created using the Dummy Classifier from Scikit-Learn.
Based on TA recommendations, the preferred prediction strategy was
‘most\_frequent’ making the model predict the most common tag every
time (non-racist). We used this baseline to compare with the
performances of BERT and CNN models. Scikit-learn’s Dummy Classifier
does not have a built-in method to handle class weights or
undersampling, meaning that class imbalance issues will not be
addressed. As baseline performance will not be acceptable either way,
class imbalance effect of f1-score was not deemed to be critical for
this iteration of the project.

**BERT**

For BERT model, the main idea is that: we preprocess the tweets into
embeddings that are easy for BERT model to train on, then we take the
`transformers` architecture and the pre-trained models to complete the
fine-tuning mission. After that, we add a linear lay on top of BERT
model as we did in the tutorial, and finally, we train the new model
based on the architecture we just built.

**CNN**

For CNN model, first we load in the tweets data set, then we encode each
token and represent each tweet as a matrix, where each row of the matrix
represent a word token, then we choose the kernel size for filtering.
After that, we use each kernel to do convolution on the same matrix that
represents a tweet and thus output the feature maps.

After we generates the feature maps, we perform `max-pooling` over each
feature map, that is to say, we only remember the largest number of each
feature map. Then we concatenate the features and pass it to linear
layer to obtain a feature vector, and finally we feed this feature
vector to the softmax layer and get the classification of the tweets.

### Experiments

We did experiments based on different hyperparameters for CNN model
mainly, since CNN model is much less time-consuming and easier to train,
also gives us high-quality predictions.

See table below for the experiments we
tried:

| Drop-out Rate | Number of Epochs | Learning Rate | Validation Accuracy | Validation F1-score (macro averaged) | Validation Loss | Training Loss |
| :-----------: | :--------------: | :-----------: | :-----------------: | :----------------------------------: | :-------------: | :-----------: |
|      0.2      |        10        |     0.01      |       0.8364        |                0.5791                |     0.6961      |    0.5007     |
|      0.5      |        10        |     0.01      |       0.8091        |                0.6057                |     0.6909      |    0.3479     |
|      0.7      |        10        |     0.01      |       0.8182        |                0.5145                |     0.8232      |    0.4335     |
|      0.2      |        10        |      0.1      |       0.1136        |                0.1020                |     0.7775      |    0.6833     |
|      0.5      |        10        |      0.1      |       0.1136        |                0.1430                |     0.7975      |    0.6720     |
|      0.7      |        10        |      0.1      |       0.1136        |                0.1020                |     0.7700      |    0.6711     |
|      0.2      |        10        |     0.001     |       0.8500        |                0.5358                |     0.6997      |    0.3892     |
|      0.5      |        10        |     0.001     |       0.8591        |                0.5426                |     0.7055      |    0.3859     |
|      0.7      |        10        |     0.001     |       0.8455        |                0.5325                |     0.7267      |    0.3862     |
|      0.2      |        5         |     0.01      |       0.8636        |                0.4945                |     0.8462      |    0.5027     |
|    **0.5**    |      **5**       |   **0.01**    |     **0.8682**      |              **0.6411**              |   **0.7073**    |  **0.3505**   |
|      0.7      |        5         |     0.01      |       0.8545        |                0.6259                |     0.6924      |    0.5396     |

From the above combinations we can observe that the best hyperparamter
combination is when drop-out rate is 0.5, number of epochs is 5, and
learning rate is 0.01. In terms of dropout rate, 0.2 seems to be the
best one for our model, while when `dropout=0.7` the model performs much
worse than other
experiments.

### Results

| Model    | Validation Accuracy | Validation F1-score (macro averaged) | Validation Loss | Training Loss |
| -------- | ------------------- | ------------------------------------ | --------------- | ------------- |
| Baseline | 0.89                | 0.47                                 | \-              | \-            |
| BERT     | 0.8864              | 0.4699                               | 0.3616          | 0.5681        |
| CNN      | 0.8682              | 0.6411                               | 0.7073          | 0.3505        |

**Baseline**

<img src="img/baseline_dev.png" alt="alt text" width="400" height="400">

*Figure 1 - Confusion Matrix (baseline model -dev
set)*

<img src="img/baseline_test.png" alt="baseline - test" width="400" height="400">

*Figure 2 - Confusion Matrix (baseline model -test set)*

Final F1-score for the baseline model was at roughly 47%. This resulted
from the baseline model predicting the most common label every time
(non-racist). Due to class imbalance in the dataset, both f1-score and
accuracy performance was relatively high despite predictions being
unacceptable.

**BERT Model**

As we can see from the table above, the BERT model has a very high
validation accuracy score, which is 0.8864. However, this does not prove
anything since BERT model might also naively predict the same tag just
as the baseline model does. Therefore, we need to look at the f-score of
BERT model, which is 0.4699. Clearly the f-score is even less than
baseline model, so we would not say that BERT model is a good choice
here for the tweets classification task.

Since the training loss (0.5681) here is much higher than the validation
loss (0.3616), we infer that this could be a underfitting model, which
requires more complicated networks.

**CNN Model**

<img src="img/CNN_dev.png" alt="CNN - dev" width="400" height="400">

*Figure 3 - Confusion Matrix (CNN model -dev set)*

<img src="img/CNN_test.png" alt="CNN - test" width="400" height="400">

*Figure 4 - Confusion Matrix (CNN model -test set)*

From the CNN row of the result table, we can observe that CNN model has
a decent validation accuracy, which is 0.8682 (although a bit lower than
baseline model and BERT model), and at the same time has a very high
f-score, which is over 0.64, based on the small data set we have. (Note
that in \*Related Work\*\* section, there is a model in the paper which
only achieves a f-score of above 0.5 with about the same amount of data
set as ours). Therefore, we can tell that our CNN model predicts the
corresponding tags based on what it learns from training set, rather
than naively “guess” the same tag every time as the baseline model does.

Additionally, since our CNN model has a validation loss of 0.6909 and a
training loss of 0.3479, we conclude that the model is a bit
overfitting. Except for that, the performance of CNN model is much
better than any other models in our project.

### Conclusion and Future Work

  - Both BERT and CNN beat the baseline Dummy Classifier
  - CNN has a higher f1-score and less time-consuming than BERT model
  - CNN outperforms other models we built in the entire project

Therefore, the basic conclusion is that CNN is least time-consuming and
has the highest f1-score, so it outperforms any other models in our
project.

In this project we encountered some challenges:

**The First Challenge**: Tweets annotation can be ambiguous: It relies
heavily on human judgement of what is racist and what is not, especially
when there are more than one annotators annotating, the results can be
unreliable.

**Future Work I**: We can fix this by developing a rigorous standard for
annotating the tweets, and it will be easy for each annotator to employ
and produce more consistent annotations among different annotators;

**Future Work II**: Another thing we can do is that instead of
annotating manually, we can implement interannotator agreement to reduce
the ambiguouty risks.

**The Second Challenge**: We spent a significant amount of time
preparing annotations for the tweets before actually building the
models. So we had limited annotated data.

**Future Work III**: What we can do is to prepare a larger amount of
racist data to improve the model accuracy.

**Future Work VI**: Another future work We can also do is error analysis
, for example, how the sentence length can affect model performance, or
the critical words in classification, etc.

### References

**Project
    code**

1.  <https://github.ubc.ca/MDS-CL-2019-20/COLX_585_trends_students/blob/master/labs/Lab1/cnn_text.ipynb>
    </br>
2.  <https://github.ubc.ca/MDS-CL-2019-20/COLX_585_trends_students/blob/master/labs/Lab2/bert_pytorch.ipynb>
    </br>
3.  <https://github.ubc.ca/chan111j/group_1_trends_project/blob/master/Milestone_4/filter_preprocess_tweets.ipynb>
    </br>
4.  <https://github.ubc.ca/chan111j/group_1_trends_project/blob/master/Milestone_4/Twitter_extraction.ipynb>
    </br>
5.  <https://github.ubc.ca/chan111j/group_1_trends_project/blob/master/Milestone_4/baseline_model_test.ipynb>
    </br>
6.  <https://github.ubc.ca/chan111j/group_1_trends_project/blob/master/Milestone_4/CNN_model.ipynb>

**Milestone
    reports**

1.  <https://github.ubc.ca/chan111j/group_1_trends_project/blob/master/Milestone_1/Milestone_1.md>
    </br>
2.  <https://github.ubc.ca/chan111j/group_1_trends_project/blob/master/Milestone_2/Milestone2.md>
    </br>
    3.https://github.ubc.ca/chan111j/group\_1\_trends\_project/blob/master/Milestone\_3/Milestone\_3.md

**Links to papers**

  - Cao, S. (2019). Google’s Artificial Intelligence Hate Speech
    Detector Has a ‘Black Tweet’ Problem. The Observer. Retrieved on
    April 4, 2020 from
    <https://observer.com/2019/08/google-ai-hate-speech-detector-black-racial-bias-twitter-study/>

  - Gambäck, B., & Sikdar, U. K. (2017, August). Using convolutional
    neural networks to classify hate-speech. In Proceedings of the first
    workshop on abusive language online (pp. 85-90).

  - Kwok, I. and Wang, Y. (2013). Locate the Hate: Detecting Tweets
    against Blacks. AAAI. Retrieved on April 4, 2020 from
    <https://www.semanticscholar.org/paper/Locate-the-Hate%3A-Detecting-Tweets-against-Blacks-Kwok-Wang/db5511e90b2f4d650067ebf934294617eff81eca>

  - MacAvaney S, Yao H-R, Yang E, Russell K, Goharian N, Frieder O
    (2019) Hate speech detection: Challenges and solutions. PLoS ONE
    14(8): e0221152. <https://doi.org/10.1371/journal.pone.0221152>.
    Retrieved on April 4, 2020 from
    <https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0221152>

  - Paraschiv, A., & Cercel, D. C. (2019). UPB at GermEval-2019 Task 2:
    BERT-Based Offensive Language Classification of German Tweets. In
    Preliminary proceedings of the 15th Conference on Natural Language
    Processing (KONVENS 2019). Erlangen, Germany: German Society for
    Computational Linguistics & Language Technology (pp. 396-402).
