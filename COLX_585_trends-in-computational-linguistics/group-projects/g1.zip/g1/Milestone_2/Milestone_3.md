Milestone\_3
================
Naga Sirisha
11/04/2020

### Introduction

Our project is the “Racism detection of tweets in the context of
COVID-19”. This is a “classification task” of the intent of the tweet.
The task involves that we create a dataset for the tweets and split the
dataset into training, development and testing dataset. We annotated
roughly 1000 tweets into “Racist” and “Non-racist” tweets. We will use
this tagged data to train model and classify the rest of the tweets. The
annotation guidelines will be discussed below.

**Motivation:**

The motivation for pursuing this us that the present unprecedented times
of the pandemic of COVID-19, there is a plethora of negative comments
that are circulated in the social media platform. This propagation of
negative comments which are directed towards a specific ethnic group
leads to harmful impacts in the society. Our motivation is to build a
model that can identify such tweets that contains racist comments. This
could be incorporated to “moderate” the contents of any platform.

Our contribution of the model will be significant since it is
domain-specific “COVID-19”.

<u>Our Definition of racism:</u> Negative comments that are subjected
towards a specific ethnic group.

**Data:**

  - We are using the data by scraping the famous social-media platform
    “Twitter”. We scraped half of our dataset from Twitter using the
    code we built, the tweets are fetched of the users from across
    different parts of the world.
  - The rest of the part of the dataset is used from the tweets provided
    by the teaching team.
  - The online social-media platform Twitter, according to
    [this](https://www.omnicoreagency.com/twitter-statistics/) platform
      - User profiles: 48.35 million Twitter users are American, 35.65
        million are Japanese, 13.9 million are Russian and 13.7 million
        are from the U.K. We will only collect English tweets, so we
        expect the majority of the users to be from North America and
        the United Kingdom.
      - Tweet length: maximum length is 280 characters, however Twitter
        reports less than 1% of tweets reach the maximum and only 12%
        reach 140 characters
  - We scraped some particular hashtags which we think might be useful
    in extraction of the racist comments in order to mitigate the class
    imbalance in the dataset. This an application of “distant
    supervision” of unlabelled data for Information retreival.
  - So far we have annoted 1000 tweets manually, we have done this
    because it was difficult to find already annotated data online, we
    have found one discussed in
    [this](https://www.aclweb.org/anthology/W16-5618.pdf) paper, but it
    has tweet\_ids instead of the tweet\_text and we plan to use this
    data set as well in the upcoming milestones if time allows.
  - Final dataset will be a minimum of 1000 tweets, with additional
    tweets to be annotated depending on time requirement. Initial
    experiments will determine how much more data is required.
    Annotation methodology

| Tweet Information           | Count  |
| --------------------------- | :----: |
| Extracted Tweet Count       | 50,000 |
| Staff side Tweet Count      | 25,000 |
| Final Annotated Tweet Count |  1000  |

**Annotators**:

  - Pandramishi Naga Sirisha
  - Jon T.K. Chan

We will see the CNN model performance so far with this data and if the
performance is poor, will consider doing a inter-annotator agreement.

**Annotation guidelines**:

For this model, we are considering the binary classification task
between racist and non-racist tweets. Depending on model performance,
model may be adjusted to add a third label (ambiguous, hateful, other).
Tweets will be labelled manually by the project team using the following
criteria.

**Guidelines for annotating the tweet as “Racist” :**

  - Racist slang is used

> fuck off china causing harm to the world no china disgusting china
> dirty china covid19=made in china \#NoChina \#fuckchina \#dirtychina
> \#china \#ChinaVirus \#ChinaLiedAndPeopleDied \#China\_is\_terrorist
> \#ChinaCoronaVirus \#ChinaIsAsshoe \#harmful \#pleasefuckoff
> \#dontbuychinese <https://t.co/EYS1D892Dy>

  - Tweet content targets a particular ethnic/cultural group and refers
    to them in a negative light.
  - In the context of COVID-19, Tweet includes statements that
    exaggerate or assigning intention towards China, Chinese or a
    particular country.
  - Unfounded hateful tweets are racist.

> Never believe China\! \#ChinaVirus \#ChinaLiedAndPeopleDied
> <https://t.co/yDQUpWk1hm>

  - Hatefulness towards communism which is baseless.

> @tedcruz Disgusting communist party \#ChineseVirus
> \#ChinaLiedAndPeopleDied <https://t.co/ejarK29IF7>

**Guidelines for annotating the tweet as “Non-racist” :**

  - Generic informational tweets or reporting news articles.

> Here’s how \#ChinaLiedAndPeopleDied: 1. China hid reports of the virus
> for weeks. 2. China targeted the whistle-blowers. 3. China destroyed
> test samples of patients. 4. China lied to the world about the
> seriousness of the situation & death toll. \#ChineseVirus
> <https://t.co/qSFVXLSb1a>

  - Hatred towards a particular person is not considered as racism. Ex:
    Xi-Ping

> Partners in crime WHO cheif @DrTedros and China’s president
> \#XiJinping  
> \#ChineseVirusCorona \#XijinpingVirus \#COVID19 \#Covid\_19
> \#coronavirus \#corona \#China \#ChinaLiedAndPeopleDied
> <https://t.co/uRFSkrEZfI>

  - Hatefulness or criticism towards a political party, this is seen as
    criticizing a Government and may not be generally tagged as racist.
    Ex: Chinese Communist Party, Chinese Government
  - Text that is expressing negative emotion without assigning blame to
    an ethnic or racial group.
  - Hateful tweet where the only racist part is the hashtag and the
    hashtag is not being used in context with the rest of the tweet text
  - Tweets that could be racist, but reference a potentially racist
    external media (link to video, meme, etc) as we are not processing
    any videos or images.

**Resolving ambiguity, sarcasm and dog-whistle type racism**

  - For initial trials, tweets that are ambiguously racist will be
    labelled as non-racist. The model’s current iteration is concerned
    with identifying tweets that are obviously racist based on text
    content, and any ambiguity introduced by sarcasm or word use will
    not be considered until later milestones.

> China Warmth❤️ Please STOP scolding China🙅🏻 ♀️ You can not love, but
> please do not hurt❤️ China is also our most precious treasure❤️
> Love\&Peace🙏🏻 \#China \#ChineseCoronaVirus \#ChinaVirus \#ChinaMustPay
> \#ChinaLiedAndPeopleDied \#ChinaIsAsshoe \#China\_is\_terrorist
> \#ChinaWuhanVirus <https://t.co/9FoaeSPCXc>

  - When assigning annotations, hashtags will be considered in context
    with tweet content. When hashtags are used as part of the tweet
    sentence, combined interpretation will be considered when
    determining between racist and non-racist. However, tweets will be
    labelled non-racist if the only racist component is the mentioned
    hashtags.

  - For this model, certain supplementary tweets will be ignored. URLs
    and mentions of other Twitter users will not be considered any
    different from other tokens of the text. This means that if the
    tweet cannot be deemed racist using only the tweet text (must be
    viewed as an image or supplementary article), it will be labelled as
    ‘non-racist’.

### Addressing the feedback from Milestone\_1

1.  Using distant supervision we have extracted a huge collection of
    3000 tweets of a certain hashtag \#ChinaLiedAndPeopleDied and then
    manually annotated them based on agreed annotation guidelines. We
    have used this method as it has more percentage of racist tweets as
    compared to tweets from a generic hashtag like \#covid-19. This is
    in effort to make the dataset more balanced. It also makes the
    annotations easier instead of going through a large number of tweets
    to find particularly racist tweets. Hence, we are using distant
    supervision to reduce the effort but are not completely relying on
    it.

2.  As we have ethically pulled the data from Twitter and the github
    repository is private to the team and the data we have is pretty
    small approx ~200KB, storage of data has not been a road blocker so
    far.

3.  As of now we are using CNN model for our data. We may still use
    particularly harsh racist hashtags after thorough scrutiny like
    \#Chinamurderers etc which have almost 90% of the tweets are racist
    to further augment our training data. We are also considering using
    BERT in the upcoming milestones as well us using a pre-built lexicon
    of words which are outrightly racist.

4.  We have used the above listed established guidelines for annotating
    the tweets after discussing with our team on how to annotate the
    tweets and resolve ties in cases of ambiguity or sarcasm.

5.  This model can be leveraged as a content moderation tool, by any
    social-media platform or if any individual who hosts a website or
    blog we can use this model to moderate/control the comments.

6.  Yes, one of the team mates have worked on twitter data before. **The
    following are the preprocessing steps taken:**

<!-- end list -->

  - While extracting the tweets for download, we have applied a filter
    to remove “retweets”
  - NLTK has a package called “tweepy” to deal with twitter data, we
    have used this package for deleting duplicated tweets where the
    tweet\_id is different but the tweet\_text is the same.
  - While extracting the tweets for download, we made sure to get the
    complete tweet’s text (not cut off due to 140 character limit).
  - If tweets conatin hyperlinks, then that tweet URL should be less
    than 50% of characters in tweet.
  - Tweet mentions and hashtags do not make up more than 75% of
    characters in tweet

<!-- end list -->

7.  We are using word embeddings for this Milestone.

### Methods and Engineering

To be written by Pan

### Evaluation:

We will use *“macro”* averaged **f1-score** for the evaluation of the
system. We pick this because our task is a classification problem and
perhaps we will run into a class imbalance problem because of the
inherent nature of the problem and the data, that most tweets that are
published are **not racist** according to the *“Pollyanna Hypothesis”*
of data.

**Evaluation on sample data for tentative CNN model:**

To be written by Pan

### Challenges

  - Extraction of tweets :

  - Ambiguous Tweets classification : relies on human judgement of what
    is racist

  - Limited annotated data : Significant time goes into preparing
    appropriate dataset before model can acutally be built

### Results

To be written by Pan

### Previous Work

  - Gamback and Sikdar (2017) has previously used CNN models on 4 label
    classification. Using a set of approximately 6500 tweets, models
    were trained to classify for 4 labels: Rasicm, Sexism, Both (racism
    and sexism), and non-hate-speech. 4 CNN models were tested to
    evaluate effect of word2vec and character N-grams on model
    performance. These models were compared against a baseline logistic
    regression classifier in terms of precision, recall, F1-score. Using
    CNN and word2vec embeddings, The highest F1-score was found to be
    78.3%. Embeddings using 4 character grams were tested in 2 other
    models, though Fscore was not improved. It was noted that when
    compared to baseline models (logistic regression), Fscore was
    improved but recall was better than all of the CNN models. For this
    project, members will note that improvements in F1-score may not
    result in an improvement in all metrics.

  - Paraschiv and Cercel (2019) used several BERT models to classify
    tweets in german. Classification tasks include binary classification
    (offensive vs non-offensive) and fine grained classifcation of
    tweets(determining between profanity, insult, and abuse).
    Classification was done using a BERT model (12 transformer blocks,
    12 attention heads) with two pretraining phases. The model was
    pre-trained on three corpora before tests were conducted, suggesting
    that this project may be interested in looking into pretraining the
    model given the limited classification data. Both tasks were
    performed on a tweet set of 12,500 tweets, and best resulting
    F1-scores were 76.95% and 70.84% for the two classifcation tasks
    respectively.

### References

  - Gambäck, B., & Sikdar, U. K. (2017, August). Using convolutional
    neural networks to classify hate-speech. In Proceedings of the first
    workshop on abusive language online (pp. 85-90).

  - Paraschiv, A., & Cercel, D. C. (2019). UPB at GermEval-2019 Task 2:
    BERT-Based Offensive Language Classification of German Tweets. In
    Preliminary proceedings of the 15th Conference on Natural Language
    Processing (KONVENS 2019). Erlangen, Germany: German Society for
    Computational Linguistics & Language Technology (pp. 396-402).
