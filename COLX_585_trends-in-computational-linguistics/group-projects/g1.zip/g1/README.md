# group_1_trends_project

**Milestone 1**

[Milestone_1 Project proposal](https://github.ubc.ca/chan111j/group_1_trends_project/blob/master/Milestone_1/Milestone_1.md)


**Milestone 2**

[Milestone_2 Markdown File](https://github.ubc.ca/chan111j/group_1_trends_project/blob/master/Milestone_2/Milestone2.md)

[Milestone_2 R Markdown File](https://github.ubc.ca/chan111j/group_1_trends_project/blob/master/Milestone_2/Milestone2.Rmd)

[Twitter Extraction Code](https://github.ubc.ca/chan111j/group_1_trends_project/blob/master/Milestone_2/Twitter_extraction.ipynb)

[Twitter config file](https://github.ubc.ca/chan111j/group_1_trends_project/blob/master/Milestone_2/config_ini_trends.ini)

[Annotated Data Set](https://github.ubc.ca/chan111j/group_1_trends_project/blob/master/Milestone_2/final_annotated_corpus.csv)

[CNN Model Code](https://github.ubc.ca/chan111j/group_1_trends_project/blob/master/Milestone_2/cnn_text.ipynb)

[BERT Model Code](https://github.ubc.ca/chan111j/group_1_trends_project/blob/master/Milestone_2/bert_pytorch.ipynb)

**Milestone 3**

[Milestone_3 Markdown File](https://github.ubc.ca/chan111j/group_1_trends_project/blob/master/Milestone_3/Milestone_3.md)

[Milestone_3 R Markdown File](https://github.ubc.ca/chan111j/group_1_trends_project/blob/master/Milestone_3/Milestone_3.Rmd)

[best model](https://github.ubc.ca/chan111j/group_1_trends_project/blob/master/Milestone_3/cnn_text.ipynb)

**Milestone 4**

[presentation](https://github.ubc.ca/chan111j/group_1_trends_project/blob/master/Milestone_4/Racism_Detection_For_COVID-19.pptx)

[Milestone4](https://github.ubc.ca/chan111j/group_1_trends_project/tree/master/Milestone_4)

