Domain-specific Racism detection in Tweets
================
Naga Sirisha
01/04/2020

### Repo setup

The following is the link to our github repository:

`https://github.ubc.ca/chan111j/group_1_trends_project/tree/master`

There are 4 branches one for each of our team members:

  - Pandramishi Naga Sirisha:
    `https://github.ubc.ca/chan111j/group_1_trends_project/tree/Nagasiri_branch`
  - Jon T.K. Chan :
    `https://github.ubc.ca/chan111j/group_1_trends_project/tree/jon_tk_chan`
  - Zhongyu (Pan) :
    `https://github.ubc.ca/chan111j/group_1_trends_project/tree/Zhongyu_Pan`

<u>Repository organisation:</u>

  - Final work for submission will be pushed to the master branch
  - We will have one folder for the written material for each
    `Milestone_<number>`, the README.md will have the links to the
    required data and code.
  - The code will be organised into the `code` folder.
  - The data will be organised in to the `data` folder.
  - The images will be organised in to `imgs` folder in the respective
    Milestone folder.

### Teamwork Contract

**Distribution of work**

  - The work will be distributed within the team members in a fair and
    equitable way.
  - We agree that each member spends about 8 hours minimum or more if
    necessary.

**Meeting expectation**

  - We will meet every 2 days on a virtual call as a group call on
    slack.
  - Daily text updates on the slack group.
  - The goal is to discuss about the requirements of that week’s
    Milestone deliverables before the lab hours, so that we can consult
    with the TAs and lab instructors in the lab hours.
  - We can schedule more meetings on an ad-hoc basis with some prior
    notice, depending on the availability of the team members.
  - We have created a slack group where will be taking group calls and
    communicating for any project related queries.
  - For every meeting, we will create a general “To-do” list for the
    action items of the milestone to be shared on the slack channel.
  - All the team members are available on Fridays, weekday evenings and
    weekends.
  - Regarding how we communicate with each other (both online and
    in-person), we will follow the Code of Conduct described below.

**Deliverables Style Expectation**

  - We will try to split the work wherever possible so that members
    could get freedom to work on their time.
  - Later, We will review the work done by each member and provide
    feedback if possible and integrate the work .
  - The contribution of the work by each member will be listed wherever
    necessary.

**Quality of work Expectation**

  - To create good quality work/deliverables for each milestone.
  - To be given tasks that are agreeable to each of the team member.
  - To evenly distribute the deliverables.
  - To deliver the expected quality of work by the prior decided
    timeline and keep everyone in loop if there is any expected delay.

**Project Management Expectations**

  - The project managers will be assigned democratically depending on
    the required task for the milestones across the project at the start
    of the week.

For example, for this week

  - Git repository: Jon

  - Writing: Naga Sirisha

  - Tweet extraction: Jon and Pan

  - The project manager(s) will be responsible to ensure that the task
    is completed within the time-line, keep updating the team regarding
    the progress of their work, if needed to delegate the task he/she
    will be responsible for communicating clearly about the sub-tasks to
    the team members and the time-line.

**Code of Conduct**

  - We will treat each other with respect.
  - Equal oppurtunity will be given to every team member to make sure
    they are heard and their opinion/feedback will be discussed for pros
    and cons depending on the project requirement.
  - Decisions will be taken by reaching consensus.
  - Any conflict of opinion if arises will be resolved openly in a
    respectful manner.

## Project proposal

### Introduction

Our project is the “Racism detection of tweets in the context of
COVID-19”. This is a “classification task” of the intent of the tweet.
The task involves that we create a dataset for the tweets and split the
dataset into training, development and testing dataset. We will annotate
the tweets into “Racist” and “Non-racist” tweets. We will use this
tagged data to train model and classify the rest of the tweets.

**Motivation:**

The motivation for pursuing this us that the present unprecedented times
of the pandemic of COVID-19, there is a plethora of negative comments
that are circulated in the social media platform. This propagation of
negative comments which are directed towards a specific ethnic group
leads to harmful impacts in the society. Our motivation is to build a
model that can identify such tweets that contains racist comments. This
could be incorporated to “moderate” the contents of any platform.

Our contribution of the model will be significant since it is
domain-specific “COVID-19”.

<u>Our Definition of racism:</u> Negative comments that are subjected
towards a specific ethnic group.

**Data:**

  - We will be using the data by scraping the famous social-media
    platform “Twitter”. We will scrape the tweets of the users from
    across different parts of the world and use this as a dataset.
  - The online social-media platform Twitter, according to
    [this](https://www.omnicoreagency.com/twitter-statistics/) platform
      - User profiles: 48.35 million Twitter users are American, 35.65
        million are Japanese, 13.9 million are Russian and 13.7 million
        are from the U.K. We will only collect English tweets, so we
        expect the majority of the users to be from North America and
        the United Kingdom.
      - Tweet length: maximum length is 280 characters, however Twitter
        reports less than 1% of tweets reach the maximum and only 12%
        reach 140 characters
  - We will scrape some particular hashtags which we think might be
    useful in extraction of the racist comments in order to mitigate the
    class imbalance in the dataset. This an application of “distant
    supervision” of unlabelled data for Information retreival.

Example of target hashtags to get “*Racist*” posts:

  - \#ChineseVirus
  - \#ChinaLiedAndPeopleDied
  - \#ChinaVirus

Example of target hashtags to get “*Non-racist*” posts:

  - \#COVID-19
  - \#CoronaVirus

**Corpus Description**

  - **Language:** English
  - **Genre/domain:** COVID-19 related posts
  - **Size:** We aim to build a dataset of atleast 1000 tweets.
  - **Information retreival:** We will get a `Twitter developer access`
    to the `Twitter API`, this will give us public and private `secret
    keys` to access the API. We will write Python code to extract the
    relavant tweets by the hashtags mentioned above. We use this keys to
    authenticate to the API inside the code, and thus we are *ethically*
    scraping the data from the web.
  - **Data Storage:** The tweets extracted will be pre-processed and
    stored in text files or .csv files.

**Engineering Methods**

  - **Computing Infrastructure:** We will be using our personal
    computers for running Python code in the process of information
    retreival, we may resort to using Google colab for models used for
    deep learning techniques.
  - **Baseline methods:** We will use simple **“Naive Bayes”** or
    **“Logistic Regression”** classifier to form a baseline model.
  - **Deep Learning methods:** We plan to use the **Convoluted Neural
    networks** for performing deep learning tasks. However, given the
    limited time and a small dataset we are apprehensive if the deep
    learning models may show better performance than the base line
    models for this binary classification task.
  - **Framework**:
      - We will use Python for data extraction and for the base line
        model.
      - We will use PyTorch for deep learning techniques.

### Previous Works

For this project, several papers and articles will be referenced when
determining the scope and methodology of this project. This section will
be expanded upon in further milestones.

MAcAvaney et. al. (2019) used a Multiview SVM model with C = 0.1 to
identify hate speech online. Evaluation methods include accuracy and
macro-averaged F1 score, which we plan to use for our model as well. The
paper also used a BERT model, which could potentially be part of our
solution depending on feasibility of training. Challenges that the paper
mentions include ambiguous context of words that appear to be hate
speech (person A may be tagged as delivering hate speech even if they
are quoting and condemning the hate speech from person B). Specifics of
the RNN structure will be explored when building this project’s model.

Kwok and Wang (2013) outlines issues with a baseline non-RNN model that
this project can seek to overcome. The paper used a Naive Bayes
classifier to classify racist and non-racist tweets using around 24,000
tweets in a balanced dataset. This model was only capable of identifying
Unigram occurrences of derogatory words, meaning that no context could
be established in terms of how words would interact or be used in
non-intentional ways. Accuracy in this model was around 76%, suggesting
that an RNN model used on the similar dataset would be able to achieve
increased performance.

Real-world pplications of the model must be considered when evaluating
model performance. Contextual issues with hate speech modelling is
further reported by The Observer, which explains how machine learning
models incorrectly label text that is used in relatively innocent
contexts tagging the user as being ‘hateful’ when using particular
vocabulary. This can result in the misidentification of authors as
spreading ‘hate speech’ when a human would deem the tweet as innocent.

**Evaluation**

We will use *“macro”* averaged **f1-score** for the evaluation of the
system. We pick this because our task is a classification problem and
perhaps we will run into a class imbalance problem because of the
inherent nature of the problem and the data, that most tweets that are
published are **not racist** according to the *“Pollyanna Hypothesis”*
of data.

**Conclusion**

The goal of our project is to build a Neural machine learning model, to
classify a given set of comments into Racist or Non-racist comments.
This model can be leveraged as a content moderation tool, by any
social-media platform or if any individual who hosts a website or blog
we can use this model to moderate/control the comments.

**References**

Cao, S. (2019). Google’s Artificial Intelligence Hate Speech Detector
Has a ‘Black Tweet’ Problem. The Observer. Retrieved on April 4, 2020
from
<https://observer.com/2019/08/google-ai-hate-speech-detector-black-racial-bias-twitter-study/>

Kwok, I. and Wang, Y. (2013). Locate the Hate: Detecting Tweets against
Blacks. AAAI. Retrieved on April 4, 2020 from
<https://www.semanticscholar.org/paper/Locate-the-Hate%3A-Detecting-Tweets-against-Blacks-Kwok-Wang/db5511e90b2f4d650067ebf934294617eff81eca>

MacAvaney S, Yao H-R, Yang E, Russell K, Goharian N, Frieder O (2019)
Hate speech detection: Challenges and solutions. PLoS ONE 14(8):
e0221152. <https://doi.org/10.1371/journal.pone.0221152>. Retrieved on
April 4, 2020 from
<https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0221152>
