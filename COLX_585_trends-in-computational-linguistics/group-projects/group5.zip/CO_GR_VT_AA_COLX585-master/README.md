# COVID-19 Racism & Hate Speech Project
This is the project for COLX 585: Trends in Computational Linguistics


### Introduction:
This is the README file for the group project. Group members include:       

Name         | Slack Handle   | Github Handle
------------ | ---------------|-----------------
Annie         | @Annie An    | @annie
Chidera          | @Chidera Okoma    | @Chidera0
Varun     | @Varun Tulasi  | @vtulasi
Gracie       | @Gracie        | @papi998


### Week 1: 
* Task 1: [Repo setup](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/tree/master)
* Task 2: [Teamwork contract](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/week1/teamwork_contract.md)
* Task 3: [Project proposal](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/week1/w1_project_proposal.md)
* Task 4: [Prompt completion](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/issues)  


### Week 2:
* Task 1: [Project progress report](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/week2/week2_progress_report.md)
* Task 2: [Data preprocessing](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/week2/preprocessing.ipynb)
* Task 3: [Annotation task](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/data/annotated_covid.xlsx)
* Task 4: [Baseline model using BERT](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/week2/baseline_BERT.ipynb)
* Task 5: [Prompt completion](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/issues)  

### Week 3:
* Task 1: [Project progress report](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/week3/week3_project_report.md)
* Task 2: [Improved BERT](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/week3/baseline_BERT_re-trained.ipynb)
* Task 3: [CNN](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/week3/cnn_trained_on_covid19.ipynb)
* Task 4: [Prompt completion](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/issues)  
* Task 5: [Self-training_in_progress](-)

### Week 4:
* Task 1: [Final project report](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/week4/final_project_report.md)
* Task 2: [BERT fine-tuned model](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/week4/baseline_BERT_re_trained.ipynb)
### Resource
* [unlabeled COVID-19 tweets](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/annie/data/US_data_about_covid.json)  
* [labeled hate speech tweets](https://github.com/aitor-garcia-p/hate-speech-dataset)
* [preprocessed hate speech tweets](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/data/tweet_hate_preprocessed.csv)
* [preprocessed COVID-19 tweets](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/data/COVID_19_preprocessed.csv)
* [Labeled COVID-19 tweets](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/data/annotated_covid.xlsx)
