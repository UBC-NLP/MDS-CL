### colx_585_week1_milestone_proposal 


### Introduction
This is the group project proposal for the course colx_585. Team members include Annie, Chidera, Varun, and Gracie. We will focus on COVID-19 Racism & Hate Speech. The purpose of this proposal is to give an overview of our plan for the project, including motivation, data, engineering, previous works, conclusion and references. 


### Motivation and Contributions/Originality:
The COVID-19 Racism & Hate Speech arouses our interest because as the coronavirus spreads, fear is [fueling racism and xenophobia](https://www.cnn.com/2020/01/31/asia/wuhan-coronavirus-racism-fear-intl-hnk/index.html). There are [concerns](https://www.thelancet.com/journals/lanpsy/article/PIIS2215-0366(20)30089-4/fulltext) over mental health problems for those who are attacked, such as denial, stress, anxiety, and fear. Those who are considered contagious are also at the risk of hate crimes.
![Stop Using The Coronavirus As An Excuse To Be Racist](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/week1/w1_stop_using_the_coronavirus_as_an_excuse_to_be_racist.jpg)      


These are examples for how people all around the world abuse "each other":    

Place  | Time  | Event
-------| -------------|-------------
Japan  | Jan, 2020| #ChineseDon’tComeToJapan, Chinese visitors were tagged as dirty, insensitive, and bioterrorist 
France | Feb, 2020| #JeNeSuisPasUnVirus, an Asian appealed on Twitter: "I'm not a virus! I know everyone's scared of the virus but no prejudice, please."
UK     | Feb, 2020| UK soccer star Dele Alli put a video on twitter where he mocked an Asian man over the coronavirus before panning to hand sanitizer

As twitter is an influential social media website, it can reduce such "abuse" by building a system to monitor and regulate the racism & hate speech content. It is sensible to build such system for the overall social well-being and social stability. Specifically, the system we are going to build in thie project will have the following banefits:
* It can filter inaccurate and misleading information  
* It can stop stigmatizing and harming people  
* It goes in accordance with guidance from health experts


### Data:  
What kind of data will you be using? Describe the corpus: genre, size, language, style, etc. Do you have the data? Will you acquire the data? How? Where will you store your data?

We will use the [COVID-19 dataset](https://raw.github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/master/data/US_data_about_covid.json?token=AAAAOJHTOFXM4KLWGOUUPVK6SE3IW) containing around 76K raw tweets. It is in English. It is provided by our TA Ganesh. We currently store it in our [repo](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/tree/master/data). 


### Engineering:  
* Data preprocessing:
    * There are two main goals for this part. First, transform the data format into what can be fed into our model. Second, explore the data, i.e. do statistic analysis and visualization, to come up with tags for the following text classification task. We might also use induced lexicon methods such as random walk/label propogration to help generate tags. Also, we might use the [detection of emotion](https://www.aclweb.org/anthology/P17-1067/) for the same purpose. 
* Baseline methods: 
    * We will use CNN for sentiment classification and text classfication.
* Proposed methods:
    * Recurrent neural network (RNN), such as long short term memory (LSTM). LSTM can capture long-range dependencies in tweets, and it might be useful in hate speech detection.
    * Semi-supervision: COVID-19 is a new domain and annotation work is expensive and time-consuming. We will try using Domain adversarial neural network (DANN) to solve the domain adaptation problem. To be specific, we can train our classifier on the labelled data (source domain: non-COVID-19) and evaluate on the unlabeled data (target domain: COVID-19). DANN can capture shared features between two domains, COVID-19 and non-COVID-19, using labelled examples from the non-COVID-19 domain and unlabelled examples from the COVID-19 domain.
* Evaluation:
    * We will randomly sample 200 tweets from the unlabeled dataset, manually annotate them and used it as test data.


### Previous Works (minimal):
* For data preprocessing: 
    * [EmoNet: Fine-Grained Emotion Detection with Gated Recurrent Neural Networks](https://www.aclweb.org/anthology/P17-1067/). This paper gives us a way to generate potential text classification tags. 
    * [Spatiotemporal anomaly detection through visual analysis of geolocated Twitter messages](https://ieeexplore.ieee.org/abstract/document/6183572). We can learn twitter data visualization from this paper.
* For CNN:
    * [Convolutional Neural Networks for Sentence Classification](https://arxiv.org/pdf/1408.5882.pdf). This paper gives a holistic view of CNN.
    * [A Sensitivity Analysis of (and Practitioners’ Guide to) Convolutional
Neural Networks for Sentence Classification](https://arxiv.org/pdf/1510.03820.pdf). We will refer to the _methods_ part for building our CNN.
* For DANN and others:
    * [Unsupervised Domain Adaptation by Backpropagation](http://sites.skoltech.ru/compvision/projects/grl/files/paper.pdf)  
    * [Domain-Adversarial Neural Networks](https://arxiv.org/pdf/1412.4446.pdf)


### Conclusion (optional):
* Our goal in this project is to build a system for twitter so that the hate and racism speech can be detected, regularized, and suppressed in a way to keep those innocent both mentally and physically safe, as well as to construct a more positive social media environment.  
* We will use several tools learned both in previous courses (data preprocessing, data visualization, sentiment analysis) and the current one (neural networks, deep learning, CNN, etc.). Also, research skills will be honed, such as searching for information, doing literature review, writing professional reports, and making effective communication. Other interpersonal skills are expected to handle, such as team work, presentation, time management, resource allocation, and leadership.



### Reference
* [Stop Using The Coronavirus As An Excuse To Be Racist](https://www.forbes.com/sites/janicegassam/2020/03/03/stop-using-the-coronavirus-as-an-excuse-to-be-racist/#1ece65507be9)
* [Yes, we long have referred to disease outbreaks by geographic places](https://www.cnn.com/2020/01/31/asia/wuhan-coronavirus-racism-fear-intl-hnk/index.html)
* [Mental health care for international Chinese students affected by the COVID-19 outbreak](https://www.thelancet.com/journals/lanpsy/article/PIIS2215-0366(20)30089-4/fulltext)
* [The Politics of SARS: containing the perils of globalization by more globalization](https://www.jstor.org/stable/42704442?seq=1#metadata_info_tab_contents)  
* [Coronavirus: French Asians hit back at racism with 'I'm not a virus'](https://www.bbc.com/news/world-europe-51294305)


