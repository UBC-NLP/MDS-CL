# Distribution of work

Set up clear guidelines and work expectations at the beginning of each week. Assign roles and responsibilities so that each person will be making an equal contribution. Speak directly, but respectfully to the person who is not completing their work.

# Expected hours of work

Each Member of the group is expected to put in 6-8 hours of work into the group project.

# Frequency of meetings

We will meet at twice a week. Once at the beginning to discuss the distribution of work and once at the end of the week to review the work done during the week and discuss any pending tasks.

# Technology used to have online meetings

We will use Slack group calling option to have our meetings.

# Having meeting agenda and minutes

No, but during each meeting one of us we will jot down a summary of the discussions in our own notebooks and confirm with every group member about the decisions made to ensure a clear direction.

# Style of working

We will discuss on Slack and during our meetings, we will agree on the division of work.

# Submitting a written summaries of contributions of each member

No, we will not be submitting a daily written summary of contributions. 
    
# Expectations regarding quality of work

Each person is expected to complete the assigned work before the deadline. The quality of the code should be good with relevant document. Each code chunk should include a comment so that everyone in the group understands what the code is doing. Early communication is key to make sure everyone is focused on common goals. Keep goals realistic and understand that our actions affect others in the group. Make a timeline so that the group can stay on an agreed plan for getting the project done. 

# Availability of team members

The team members will be available from Monday - Friday and occationally during the weekend. 

# Project manager

There will be no project manager in our group. If there is any conflict, we will vote on it and go with the majority.

# Code of conduct

The division of work has to be agreed by everyone in the group. 


