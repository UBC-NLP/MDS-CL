### Abstract
In this paper, we report our findings on different experiments using Bidirectional Encoder Representations from Transformers (BERT) and convolutional neural networks (CNN) to train a hate speech detection system on Twitter messages. We evaluate how effective our system is in detecting hate and racism relating to COVID_19. We use a deep learning approach leveraging hate speech datasets not relating to COVID_19 to boost the performance of our model. 


### Introduction
In the past few months, the world has experienced the beginning and rapid growth of the novel COVID_19 virus (also known as coronavirus). The impact has been tremendous and it has disrupted the way we do everyday life. Non-essential businesses and schools are forced to work remotely or online. This means that a lot of communication would be done primarily on social media. In light of this, it is imperative that we create a safe environment that does not fuel hate speech, racism, anxiety and fear. 

An example of hate tweets relating to COVID-19

Place  | Time  | Event
-------| -------------|-------------
Japan  | Jan, 2020| #ChineseDon’tComeToJapan, Chinese visitors were tagged as dirty, insensitive, and bioterrorist 
France | Feb, 2020| #JeNeSuisPasUnVirus, an Asian appealed on Twitter: "I'm not a virus! I know everyone's scared of the virus but no prejudice, please."
UK     | Feb, 2020| UK soccer star Dele Alli put a video on twitter where he mocked an Asian man over the coronavirus before panning to hand sanitizer


Twitter is one of the major social media platforms, we have built a model that can detect and help regulate the amount of hate speech and racism on the platform leading to the better mental health, overall well-being and social stability of individuals.
Our model would make use of BERT and CNN to effectively build a system to identifies these threats on the platform.   

![Tweets WordCloud](../image/wordcloud.png)

### Related Works (Literature Review)

To help motivate our work, we looked at what others have done in the space of deep learning and sentiment analysis. Particularly we noted [Coooolll](https://www.aclweb.org/anthology/S14-2033.pdf) a deep learning system for Twitter sentiment classification. In this works, they used developed a system that classified tweets into positive, negative or neutral. Coooolll was built in a supervised learning framework by concatenating the sentiment-specific word embedding (SSWE) features with the state-of-the-art hand-crafted features. 

Also, we looked at the [Convolutional Neural Networks](https://arxiv.org/pdf/1510.03820.pdf) CNNs for sentence classification. In this paper, they conducted a sensitivity analysis of one-layer CNNs to explore the effect of architecture components on CNN model performance. The aim was to distinguish between important and comparatively inconsequential design decisions for sentence classification.


### Data and Model Architecture
In this project, we have used an annotated hate speech twitter dataset([not involving COVID_19](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/data/tweet_hate_preprocessed.csv)) which is publicly available to train a baseline model and we tested on a manually annotated [COVID_19 data](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/data/annotated_covid.xlsx). This served as a springboard to help build a better self-training model by fine-tuning the base model. Given that twitter data can be very noisy (using informal languages, abbreviations, elongations, emojis and emoticons) it was necessary that we preprocessed the data. We used [this](https://pypi.org/project/tweet-preprocessor/) preprocessor to clean up the dataset. 

#### BERT 
We used the Bidirectional Encoder Representations from Transformers (BERT) English uncased model for our experiment. Drawing from the [official BERT paper](https://arxiv.org/pdf/1810.04805.pdf), it is designed to pre-train deep bidirectional representations from the unlabeled text by jointly conditioning on both left and right context in all layers. As a result, the pre-trained BERT model can be fine-tuned with just one additional output layer to create state-of-the-art models for a wide range of tasks. 
![BERT Architecture](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/week3/fig2-1.png)

We added an untrained linear layer on top of it. The byte-pair encoding helps to mitigate the out of vocabulary problem when using the model on new data.

We have re-trained the baseline model ([code](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/week3/baseline_BERT_re-trained.ipynb)) with 500 annotated COVID tweets allowed the model to capture the feature of COVID tweets, validated on 300 COVID tweets and then tested on 200 COVID tweets ([data preprocessing](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/week3/preprocessing.ipynb)). We rely on the F1 score instead of accuracy because of data is highly imbalanced. The validation f1 score improved by 17% after re-training and the test F1 score improved from 41% to 79%.

The dataset is highly imbalanced, the challenge is that the majority class will outweigh the minority class. In fact, 93% is hate speech in the training data, and 70% is hate speech in 1000 manually annotated dataset ([code](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/week3/stats.ipynb)). We had tuned different weights to each class using the weight parameter in the optimizer function and the model performed the best when the weight is set to 0.95 to label 0 and 0.05 to label 1. After specifying the weight, the test F1 score improved by 1%.

#### Hyperparameter

- learning rate: we used a learning rate of 2e-5. This helps in optimizing the step size at each iteration while moving towards the minimum objective function.
- maximum gradient norm (max_grad_norm): helps to minimize overfitting. It is used to clip the global gradient norm and a value 1.0 was used in the model.
- Epoch: the number of times the entire dataset is used in training the model. The number of epoch used is 3.
- warmup_proportion: To avoid early overfitting, the warmup_proportion is used to reduce the primacy effect of early training examples.

#### Preprocessing

- The [tweet-preprocessor](https://pypi.org/project/tweet-preprocessor/) was used in cleaning up our dataset. This included removing emojis, emoticons, some special characters,  user_mentions etc and text normalizations.  
- This same preprocessing is being applied the [non_COVID 19 tweet hate speech dataset](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/data/tweet_hate_preprocessed.csv) used to build our baseline model
as well as the [COVID dataset](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/data/COVID_19_preprocessed.csv)
- Also, because of the class imbalance of most tasks like ours (more non-hate-speech than hate speech), we have performed some baseline evaluation on the dataset using majority classification. Details to this evaluation can be found [here](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/week2/preprocessing.ipynb)


#### Regularization

Regularization is added to discourage the complexity of the model and helps to solve the overfitting problem by penalizing the loss function. It works on assumption that smaller weights generate simpler model and thus helps in avoiding overfitting. In our model we use the default L2 regularization weight_decay = 0.01. In L2 regularization we force the weights to be small but not equal to zero.

### Result

Full stats code [here](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/week3/stats.ipynb)

| Models  |  Hyperparameters |Validation (non-COVID)   | Validation (COVID)  | Test Evaluation (COVID)  |
|---|---|---|---|---|
|Baseline-BERT   | 	lr = 2e-5	  | Accuracy: 0.9470, F1: 0.8122  |  - | Accuracy: 0.728, F1: 0.522  |
|BERT hyper-parameter tuning	   | lr = 2e-5, weight_decay = 0.3  | 	Accuracy: 0.9459, F1: 0.8165  | Accuracy: 0.705, F1: 0.514  | Accuracy: 0.685, F1: 0.556  |
| BERT hyper-parameter tuning  | lr = 0.001, weight_decay = 0.3  | 	Accuracy: 0.9179, F1: 0.8012  |  Accuracy: 0.890, F1: 0.471 | Accuracy: 0.698, F1: 0.412  |
|BERT fine-tuned on 500 COVID tweets   | lr = 2e-5  | 	Accuracy: 0.9491, F1: 0.8173  |  Accuracy: 0.875, F1: 0.467 | Accuracy:0.787, F1: 0.785  |
|BERT fine-tuned on 500 COVID tweets   | lr = 2e-5, weight = torch.tensor([0.95,0.05])  | 	Accuracy: 0.9582, F1: 0.8253  |  Accuracy: 0.880, F1: 0.469 | Accuracy:0.810, F1: 0.801  |
|CNN         |  lr = 1e-2, dropout = 0.5  |  - |  Accuracy: 0.890, F1: 0.471        | Accuracy: 0.407, F1: 0.289|

### Conclusion and Future work
In this project, we have applied BERT and CNN on the labeled hatespeech twitter data and unlabeled covid-19 hatespeech twitter data. Our goal is to train a covid-19 hatespeech detection system on Twitter. Our baseline BERT model trained on labeled hatespecch data and tested on 1000 manually labeled covid-19 hatespeech data has the f-score around 0.52. After fine-tuning the baseline BERT model on 500 manually labeled covid-19 hatespeech data, the f-score has reached up to 0.79. In the meantime, we use CNN as a comparison model. However, it only achieves a f-scorel less than 0.3.  

As we can see how powerful fine-tuning is, one of our future work is to use self-training to automatically give labels for the rest unlabeled covid-19 hatespeech twitters. other future works include using RoBERTa, XLNET as an improvement of current BERT model. 
