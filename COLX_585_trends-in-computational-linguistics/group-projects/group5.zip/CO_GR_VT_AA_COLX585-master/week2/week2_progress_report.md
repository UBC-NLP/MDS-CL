### colx_585_week2_progress_report 
### Introduction
This is the week2 group project progress report for the course colx_585. Our project goal is to build a hatespeech detection system for twitter. Team members include Annie, Chidera, Varun, and Gracie. This report will update the progress in this second week, including twitter data proprocessing, data annotation, building baseline model (BERT), reflection of the challenges, as well as plan for the next two weeks.  

*notes for Peter: Thanks Peter for your quick milestone1 review. It is very helpful and inspiring. After reading your comments, I talked to Chiyu about the BERT semi-supervised learning method in his paper, and thus have applied them in our project. Again, thank you very much! I didn't copy and paste milestone1 into this document because I find it more straightforword and less confusing (and save your time not to read repetitive lines that don't carry much information) to share the progress we have made this week in this report. If you want to review our last week's report, please check [here](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/week1/w1_project_proposal.md).*


### Weekly progress overview 
###### (only things changed are listed in week2, e.g. you can assume 'annotated hatespeech data' is still one of our data source in week2 though not listed.)

Week/Progress | Data  | Data Source |Methods & Engineering | Previous Works| Results | Challenges
--------------|-------|-----------------------|---------------|---------|---------------|--------
1             |unannotated corvid-19 hatespeech data; annotated hatespeech data| twitter| LSTM on word level| - | - | - 
2             |[preprocessed data](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/week2/preprocessing.ipynb); [1000 annotated corvid-19 hatespeech data](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/data/annotated_covid.xlsx);|twitter |[BERT baseline](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/week2/baseline_BERT.ipynb) |[BERT](https://arxiv.org/pdf/1810.04805.pdf) |good on training data (0.94 accuracy), poor on test data (0.72 accuracy)| *details below* 
3             |preprocess in different ways? more manual annotations? combine datasets? |twitter, semi-supervised learning model| improved BERT or try other models| [preprocess noise](https://arxiv.org/pdf/1809.00388.pdf), [self-training](https://www.aclweb.org/anthology/W19-4637.pdf) | - |-


### Challenges
- In this week, our first challenge was the dataset. Because our goal is to build a corvid-19 hatespeech classifier for twitter data. The ideal dataset will be annotated corvid-19 hatespeech tweets so that we can build supervised learning models and deep learning models. However, we only have two choice: unannotated corvid-19 hatespeech tweets, and annotated hatespeech tweets. At first, I thought there were only two ways to solve this problem (which turned out to be too pessimistic because we have more choices). First was to use annotated hatespeech tweets to build the model. Second was to manually label the unannotated corvid-19 hatespeech tweets to build the model. Both seems not that good because the former is building a model based on other dataset. The latter takes too much time. After the dicussion with Chiyu, I realized we can combine these two. The whole progress is listed as follows:
    - Build a baseline model using annotated hatespeech tweets
    - Manually label 1000-2000 corvid-19 hatespeech tweets
    - Test the model using the manually annotated tweets    
    
- Ideally, we want the data to be annotated corvid-19 hatespeech tweets. Therefore in the next week, what we will do is to:    
    - Build a self-training model to annotate corvid-19 hatespeech tweets using the 1000 annotation tweets   
    - Test the model using combined datasets  
    
- The second challenge was about the model choice. I discussed with Miikka about which model was ideal to use. At first, I thought bilstm was a good choice. I concluded that a character-based bilstm would outperform the word-based bilstm because twitter data are irregular. Later, after reading the comments and the discussion with Chiyu, I believed BPE might perform better than character-based bilstm because the BPE basically uses the subword/subunit/prefix/suffix/etc. of a token. It is more resourceful. That's why we have used the BERT as the baseline model.   

- The next challenge we have is the poor performance of BERT model. There are several ways to improve it. (*note for Peter: Please give us some food for thoughts if you have some ideas!*) 
    - For example, we can try another way to preprocess our data. Currently, we are using the tweet-preprocessor from pypi, which removes emojis, emoticons, special characters, user_mentions, and do text normalization. We may re-consider how to deal with the noisy data. Will some of them be useful? 
    - Also, we definitely need more annotated corvid-19 hatespeech twitter data. This can be achieved by either self-learning or manual annutation. (The former is preferred yet might be technically challenging.)
    - There are some labels in the annotated hatespeech twitte data that doesn't make sense. We might need to fix them first.   
    
- Another challenge is about group management, i.e. how can we guarantee everybody works/studies well, learning and contributing in the same time. I have discussed this with professor Muhammad. He has given many useful advice such as effective communicatation and efficient group meeting. Because everybody in our group is special and has our own advantages, it becomes important to me to work well enough together to make this project successful. Meanwhile, I hope we can help each other be successful (i.e. learn/get what he/she expects from the project). 


### Below are the detailed description of this week's task 
#### Preprocessing 
- The [tweet-preprocessor](https://pypi.org/project/tweet-preprocessor/) was used in cleaning up our dataset. This included removing emojis, emoticons, some special characters,  user_mentions etc and text normalizations.  
- This same preprocessing is being applied the [non_COVID 19 tweet hate speech dataset](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/data/tweet_hate_preprocessed.csv) used to build our baseline model
as well as the [COVID dataset](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/data/COVID_19_preprocessed.csv)
- Also, because of the class imbalance of most task like ours (more non hatespeech than hatespeech), we have performed some baseline evaluation on the dataset using majority classification. Details to this evaluation can be found [here](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/week2/preprocessing.ipynb)


#### Baseline model
- We used BERT as the baseline model, the [training data](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/data/tweet_hate_train.csv) is non-Covid-19 tweets, and the test data is Covid-19 tweets which we manually annotated. We fine-tuned BERT on hate speech classification task, using the pre-trained BERT model (bert-base-uncased) and added an untrained linear layer on top of it. The performance is pretty well (f1 score:0.81, accuracy 0.94), thanks to byte-pair encoding that mitigate the out of vocabulary ptoblem.


#### Annotation task 
- The annotation task for the tweets was fairly straightforward. The annotations were done for a 1000 tweets and tweets that were hateful were labelled as 1 and the ones that were not hateful were labelled as 0. There were a number of tweets where people referred to the COVID-19 virus as the "Chinese virus" or "Asian Virus" or "yellow virus". Another thing that was noticed was that there were a lot more hateful tweets in the last 300-400 tweets of the 1000 tweets. 



