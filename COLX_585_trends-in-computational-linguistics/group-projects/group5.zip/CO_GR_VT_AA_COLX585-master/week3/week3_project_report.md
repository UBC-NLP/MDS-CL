### Abstract
In this paper, we report our findings on different experiments using Bidirectional Encoder Representations from Transformers (BERT) and convolutional neural networks (CNN) to train a hatespeech detection system on Twitter messages. We evaluate how effective our system is in detecting hate and racism relating to COVID_19. We use a deep learning approach leveraging hate speech dataset not relating to COVID_19 to boost the performance of our model. 


### Introduction
In the past few months, the world has experienced the beginning and rapid growth of the novel COVID_19 virus (also known as corona virus). The impact has been tremendous and it has disrupted the way we do everyday life. Non essential businesses and schools are forced to work remotely or online. This means that a lot of communciation would be done primarily on social media. In light of this, it is imperative that we create a safe enivornment that does not fuel hate speech, racism, anxiety and fear. 
Twitter being one of the major social media platforms, we have built a model that can detect and help regulate the amount of hate speech and racism on the platform leading to the a better mental health, overall well-being and social stability of individuals.
Our model would make use of BERT and CNN to effectively build a system to identifies these threats on the platform. 


### Data and Model Architecture.
In this project, we have used an annotated hatespeech twitter dataset([not involving COVID_19](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/data/tweet_hate_preprocessed.csv)) which is publicly available to train a baseline model and we tested on a manually annotated [COVID_19 data](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/data/annotated_covid.xlsx). This served as a spring board to help build a better self training model by fine-tuning the base model. Given that twitter data can be very noisy (using informal languages, abbreviations, enlongations, emojis and emoticons) it was necessary that we preprocessed the data. We used [this](https://pypi.org/project/tweet-preprocessor/) preprocessor to clean up the dataset. 

#### BERT 
We used the Bidirectional Encoder Representations from Transformers (BERT) English uncased model for our experiment. Drawing from the [official BERT paper](https://arxiv.org/pdf/1810.04805.pdf), it is designed to pre-train deep bidirectional representations from unlabeled text by jointly conditioning on both left and right context in all layers. As a result, the pre-trained BERT model can be fine-tuned with just one additional output layer to create state-of-the-art models for a wide range of tasks. 
![BERT Architecture](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/week3/fig2-1.png)

We added an untrained linear layer on top of it. The byte-pair encoding helps to mitigate the out of vocabulary problem when using the model on a new data.

We have re-trained the baseline model ([code](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/week3/baseline_BERT_re-trained.ipynb)) with 500 annotated COVID tweets allowed the model to capture the feature of COVID tweets, validated on 300 COVID tweets and then tested on 200 COVID tweets ([data preprocessing](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/week3/preprocessing.ipynb)). We rely on the F1 score instead of accuracy because of data is highly imbalanced. The validation f1 score improved by 17% after re-training and the test F1 score improved from 41% to 79%.

The dataset is highly imbalanced, the challenge is that the majority class will outweigh the minority class. In fact, 93% is hate speech in the training data, and 70% is hate speech in 1000 manually annotated dataset ([code](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/week3/stats.ipynb)). We will fine-tuning different weights to each class using the weight parameter in the optimizer function. 

#### Hyperparameter

- learning rate: we used a learning rate of 2e-5. This help in optimizing the step size at each iteration while moving towards the minimum objective function.
- maximum gradient norm (max_grad_norm): helps to minimize overfitting. It is used to clip global gradient norm and a value 1.0 was used in the model.
- Epoch: the number time the entire dataset is used in training the model. Number of epoch used is 3.
- warmup_proportion: To avoid early overfitting, the warmup_proportion is used reduce the primacy effect of early training examples.

#### Preprocessing 
- The [tweet-preprocessor](https://pypi.org/project/tweet-preprocessor/) was used in cleaning up our dataset. This included removing emojis, emoticons, some special characters,  user_mentions etc and text normalizations.  
- This same preprocessing is being applied the [non_COVID 19 tweet hate speech dataset](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/data/tweet_hate_preprocessed.csv) used to build our baseline model
as well as the [COVID dataset](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/data/COVID_19_preprocessed.csv)
- Also, because of the class imbalance of most task like ours (more non hatespeech than hatespeech), we have performed some baseline evaluation on the dataset using majority classification. Details to this evaluation can be found [here](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/week2/preprocessing.ipynb)

#### Regularization

Regularization is added to discourage the complexity of the model and helps to solve the overfitting problem by penalizing the loss function. It works on assumption that smaller weights generate simpler model and thus helps in avoiding overfitting. In our model we use the default L2 regularization weight_decay = 0.01. In L2 regularization we force the weights to be small but not equal to zero.


#### Result

Full stats code [here](https://github.ubc.ca/chidera0/CO_GR_VT_AA_COLX585/blob/master/week3/stats.ipynb)

| Models  |  Hyperparameters |Validation (non-COVID)   | Validation (COVID)  | Test Evaluation (COVID)  |
|---|---|---|---|---|
|Baseline-BERT   | 	lr = 2e-5	  | Accuracy: 0.9470, F1: 0.8122  |  - | Accuracy: 0.728, F1: 0.522  |
|BERT hyper-parameter tuning	   | lr = 2e-5, weight_decay = 0.3  | 	Accuracy: 0.9459, F1: 0.8165  | Accuracy: 0.705, F1: 0.514  | Accuracy: 0.685, F1: 0.556  |
| BERT hyper-parameter tuning  | lr = 0.001, weight_decay = 0.3  | 	Accuracy: 0.9179, F1: 0.8012  |  Accuracy: 0.890, F1: 0.471 | Accuracy: 0.698, F1: 0.412  |
|BERT fine-tuned on 500 COVID tweets   | lr = 2e-5  | 	Accuracy: 0.9491, F1: 0.8173  |  Accuracy: 0.875, F1: 0.467 | Accuracy:0.787, F1: 0.785  |
|CNN         |  lr = 1e-2, dropout = 0.5  |  - |  Accuracy: 0.890, F1: 0.471        | Accuracy: 0.407, F1: 0.289|
